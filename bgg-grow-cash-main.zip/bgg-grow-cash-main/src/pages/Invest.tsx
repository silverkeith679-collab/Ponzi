import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { ArrowLeft, TrendingUp } from 'lucide-react';
import { format } from 'date-fns';

const Invest = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [investments, setInvestments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchInvestments = async () => {
      if (!user) return;

      const { data } = await supabase
        .from('investments')
        .select('*')
        .eq('user_id', user.id)
        .eq('status', 'active')
        .order('created_at', { ascending: false });

      if (data) setInvestments(data);
      setLoading(false);
    };

    fetchInvestments();
  }, [user]);

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-card border-b border-border px-4 py-4 flex items-center gap-3 sticky top-0">
        <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard')}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-bold">My Investments</h1>
      </div>

      <div className="p-4 space-y-4">
        {investments.length === 0 ? (
          <Card className="p-8 text-center">
            <TrendingUp className="h-12 w-12 mx-auto mb-3 text-muted-foreground" />
            <p className="text-muted-foreground mb-4">No active investments</p>
            <Button onClick={() => navigate('/top-up')} className="bg-gradient-primary">
              Start Investing
            </Button>
          </Card>
        ) : (
          investments.map((investment) => {
            const progress = ((60 - investment.days_remaining) / 60) * 100;
            const totalEarned = (60 - investment.days_remaining) * Number(investment.daily_earnings);

            return (
              <Card key={investment.id} className="p-4 space-y-3">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm text-muted-foreground">Investment Amount</p>
                    <p className="text-2xl font-bold text-primary">
                      {Number(investment.amount).toLocaleString()} UGX
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">Daily Earnings</p>
                    <p className="text-xl font-bold text-success">
                      {Number(investment.daily_earnings).toLocaleString()} UGX
                    </p>
                  </div>
                </div>


                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Progress</span>
                    <span className="font-medium">{60 - investment.days_remaining}/60 days</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                </div>

                <div className="grid grid-cols-2 gap-4 pt-2 border-t border-border">
                  <div>
                    <p className="text-xs text-muted-foreground">Days Remaining</p>
                    <p className="font-bold">{investment.days_remaining}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Total Earned</p>
                    <p className="font-bold text-success">{totalEarned.toLocaleString()} UGX</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Started</p>
                    <p className="font-medium text-sm">
                      {format(new Date(investment.created_at), 'MMM dd, yyyy')}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Expires</p>
                    <p className="font-medium text-sm">
                      {format(new Date(investment.expires_at), 'MMM dd, yyyy')}
                    </p>
                  </div>
                </div>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
};

export default Invest;
