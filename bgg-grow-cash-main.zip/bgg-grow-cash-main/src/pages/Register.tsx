import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { z } from 'zod';
import WelcomeAnnouncement from '@/components/WelcomeAnnouncement';

const registerSchema = z.object({
  username: z.string().min(3, 'Username must be at least 3 characters').max(20),
  phoneNumber: z.string().min(10, 'Invalid phone number').max(15),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  confirmPassword: z.string(),
  referralCode: z.string().optional()
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

const Register = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { signUp, user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [showWelcome, setShowWelcome] = useState(false);
  const [formData, setFormData] = useState({
    username: '',
    phoneNumber: '',
    password: '',
    confirmPassword: '',
    referralCode: searchParams.get('rx') || ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    // Only navigate if user exists and should not show welcome
    if (user && !showWelcome) {
      navigate('/dashboard');
    }
  }, [user, navigate, showWelcome]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});
    setLoading(true);

    try {
      registerSchema.parse(formData);
      
      const { error } = await signUp(
        formData.username,
        formData.password,
        undefined,
        formData.phoneNumber,
        formData.referralCode
      );

      if (error) {
        if (error.message.includes('already registered')) {
          toast.error('Username already exists');
        } else {
          toast.error(error.message);
        }
      } else {
        toast.success('Registration successful! Logging you in...');
        // Always show welcome for new registrations
        setShowWelcome(true);
        localStorage.setItem('hasSeenWelcome', 'true');
      }
    } catch (err) {
      if (err instanceof z.ZodError) {
        const fieldErrors: Record<string, string> = {};
        err.errors.forEach((error) => {
          if (error.path) {
            fieldErrors[error.path[0]] = error.message;
          }
        });
        setErrors(fieldErrors);
        toast.error('Please check your inputs');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <WelcomeAnnouncement 
        open={showWelcome} 
        onClose={() => {
          setShowWelcome(false);
          navigate('/dashboard');
        }} 
      />
      
      <div className="min-h-screen bg-background flex items-center justify-center p-3 sm:p-4">
        <div className="w-full max-w-md space-y-4 sm:space-y-6">
        <div className="text-center space-y-1 sm:space-y-2">
          <h1 className="text-3xl sm:text-4xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            BGG CASH
          </h1>
          <p className="text-sm sm:text-base text-muted-foreground">Create your account</p>
        </div>

        <div className="bg-card border border-border rounded-xl sm:rounded-2xl p-4 sm:p-6 space-y-3 sm:space-y-4">
          <form onSubmit={handleSubmit} className="space-y-3 sm:space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="username" className="text-sm">Username</Label>
              <Input
                id="username"
                value={formData.username}
                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                placeholder="Enter username"
                className="h-11"
              />
              {errors.username && <p className="text-xs text-destructive">{errors.username}</p>}
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="phoneNumber" className="text-sm">Phone Number</Label>
              <Input
                id="phoneNumber"
                value={formData.phoneNumber}
                onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
                placeholder="0700000000"
                className="h-11"
              />
              {errors.phoneNumber && <p className="text-xs text-destructive">{errors.phoneNumber}</p>}
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="password" className="text-sm">Password</Label>
              <Input
                id="password"
                type="password"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                placeholder="Enter password"
                className="h-11"
              />
              {errors.password && <p className="text-xs text-destructive">{errors.password}</p>}
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="confirmPassword" className="text-sm">Confirm Password</Label>
              <Input
                id="confirmPassword"
                type="password"
                value={formData.confirmPassword}
                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                placeholder="Confirm password"
                className="h-11"
              />
              {errors.confirmPassword && <p className="text-xs text-destructive">{errors.confirmPassword}</p>}
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="referralCode" className="text-sm">Referral Code (Optional)</Label>
              <Input
                id="referralCode"
                value={formData.referralCode}
                onChange={(e) => setFormData({ ...formData, referralCode: e.target.value })}
                placeholder="Enter referral code"
                className="h-11"
              />
            </div>

            <Button type="submit" className="w-full bg-gradient-primary h-11 text-base" disabled={loading}>
              {loading ? 'Creating Account...' : 'Register'}
            </Button>
          </form>

          <div className="text-center text-sm">
            Already have an account?{' '}
            <Link to="/login" className="text-primary hover:underline font-medium">
              Login here
            </Link>
          </div>
        </div>
      </div>
    </div>
    </>
  );
};

export default Register;
