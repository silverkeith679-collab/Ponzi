import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowLeft, Copy } from 'lucide-react';
import { toast } from 'sonner';

const PaymentDetails = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const [selectedMethod, setSelectedMethod] = useState<'MTN' | 'AIRTEL' | null>(null);
  const [loading, setLoading] = useState(false);
  const { fullName, phoneNumber, amount } = location.state || {};

  if (!fullName || !phoneNumber || !amount) {
    navigate('/top-up');
    return null;
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard!');
  };

  const handleSubmit = async () => {
    if (!selectedMethod || !user) return;
    setLoading(true);

    try {
      const { error } = await supabase
        .from('transactions')
        .insert({
          user_id: user.id,
          transaction_type: 'deposit',
          amount: amount,
          status: 'pending',
          full_name: fullName,
          phone_number: phoneNumber,
          payment_method: selectedMethod
        });

      if (error) throw error;

      toast.success('Deposit request submitted! Waiting for admin approval.');
      navigate('/dashboard');
    } catch (error) {
      toast.error('Failed to submit deposit request');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-card border-b border-border px-4 py-4 flex items-center gap-3 sticky top-0">
        <Button variant="ghost" size="icon" onClick={() => navigate('/top-up')}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-bold">Payment Details</h1>
      </div>

      <div className="p-4 space-y-6">
        <Card className="p-4 space-y-2">
          <h3 className="font-semibold">Deposit Amount</h3>
          <p className="text-3xl font-bold text-primary">{amount.toLocaleString()} UGX</p>
        </Card>

        <div className="space-y-3">
          <h3 className="font-semibold">Select Payment Method</h3>
          
          <Button
            variant={selectedMethod === 'MTN' ? 'default' : 'outline'}
            className="w-full justify-start h-auto p-4"
            onClick={() => setSelectedMethod('MTN')}
          >
            <div className="text-left w-full">
              <p className="font-bold text-lg">MTN Mobile Money</p>
              <p className="text-sm text-muted-foreground">Pay with MTN</p>
            </div>
          </Button>

          <Button
            variant={selectedMethod === 'AIRTEL' ? 'default' : 'outline'}
            className="w-full justify-start h-auto p-4"
            onClick={() => setSelectedMethod('AIRTEL')}
          >
            <div className="text-left w-full">
              <p className="font-bold text-lg">AIRTEL Money</p>
              <p className="text-sm text-muted-foreground">Pay with AIRTEL</p>
            </div>
          </Button>
        </div>

        {selectedMethod === 'MTN' && (
          <Card className="p-4 space-y-3 bg-gradient-primary text-white">
            <h3 className="font-bold">MTN Payment Details</h3>
            <div className="space-y-2">
              <div>
                <p className="text-sm opacity-90">Bank Name</p>
                <p className="font-bold">MTN</p>
              </div>
              <div>
                <p className="text-sm opacity-90">Account Name</p>
                <p className="font-bold">Bambalira silver</p>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm opacity-90">Account Number</p>
                  <p className="font-bold text-lg">0766637669</p>
                </div>
                <Button
                  variant="secondary"
                  size="icon"
                  onClick={() => copyToClipboard('0766637669')}
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </Card>
        )}

        {selectedMethod === 'AIRTEL' && (
          <Card className="p-4 space-y-3 bg-gradient-success text-white">
            <h3 className="font-bold">AIRTEL Payment Details</h3>
            <div className="space-y-2">
              <div>
                <p className="text-sm opacity-90">Bank Name</p>
                <p className="font-bold">AIRTEL</p>
              </div>
              <div>
                <p className="text-sm opacity-90">Account Name</p>
                <p className="font-bold">Bambalira Silver</p>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm opacity-90">Account Number</p>
                  <p className="font-bold text-lg">0759590343</p>
                </div>
                <Button
                  variant="secondary"
                  size="icon"
                  onClick={() => copyToClipboard('0759590343')}
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </Card>
        )}

        {selectedMethod && (
          <div className="space-y-4">
            <Card className="p-4 bg-warning/10 border-warning/20">
              <p className="text-sm">
                <strong>Important:</strong> Send exactly {amount.toLocaleString()} UGX to the account number above, then submit your request.
              </p>
            </Card>

            <Button
              onClick={handleSubmit}
              disabled={loading}
              className="w-full bg-gradient-primary"
            >
              {loading ? 'Submitting...' : 'Submit Deposit Request'}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default PaymentDetails;
