import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowLeft } from 'lucide-react';
import { format } from 'date-fns';

const Records = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [transactions, setTransactions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTransactions = async () => {
      if (!user) return;

      const { data } = await supabase
        .from('transactions')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (data) setTransactions(data);
      setLoading(false);
    };

    fetchTransactions();
  }, [user]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'text-success';
      case 'pending': return 'text-warning';
      case 'rejected': return 'text-destructive';
      default: return 'text-muted-foreground';
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'deposit': return 'Deposit';
      case 'withdrawal': return 'Withdrawal';
      case 'earning': return 'Daily Earning';
      case 'referral_bonus': return 'Referral Bonus';
      case 'welcome_bonus': return 'Welcome Bonus';
      case 're-investment': return 'Re-investment';
      default: return type;
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-card border-b border-border px-4 py-4 flex items-center gap-3 sticky top-0">
        <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard')}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-bold">Transaction Records</h1>
      </div>

      <div className="p-4 space-y-3">
        {transactions.length === 0 ? (
          <Card className="p-8 text-center">
            <p className="text-muted-foreground">No transactions yet</p>
          </Card>
        ) : (
          transactions.map((transaction) => (
            <Card key={transaction.id} className="p-4">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="font-semibold">{getTypeLabel(transaction.transaction_type)}</p>
                  <p className="text-sm text-muted-foreground">
                    {format(new Date(transaction.created_at), 'MMM dd, yyyy HH:mm')}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-lg">
                    {transaction.transaction_type === 'withdrawal' || transaction.transaction_type === 're-investment' ? '-' : '+'}
                    {Number(transaction.amount).toLocaleString()} UGX
                  </p>
                  <p className={`text-sm font-medium ${getStatusColor(transaction.status)}`}>
                    {transaction.status.toUpperCase()}
                  </p>
                </div>
              </div>
              {transaction.net_payout && (
                <p className="text-sm text-muted-foreground">
                  Net payout: {Number(transaction.net_payout).toLocaleString()} UGX
                </p>
              )}
              {transaction.payment_method && (
                <p className="text-sm text-muted-foreground">
                  Payment method: {transaction.payment_method}
                </p>
              )}
            </Card>
          ))
        )}
      </div>
    </div>
  );
};

export default Records;
