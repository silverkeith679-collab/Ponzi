import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, Users, CheckCircle, XCircle } from 'lucide-react';

const Team = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [referrals, setReferrals] = useState<any[]>([]);
  const [referralStats, setReferralStats] = useState({
    level1: { active: 0, inactive: 0, earnings: 0 },
    level2: { active: 0, inactive: 0, earnings: 0 },
    level3: { active: 0, inactive: 0, earnings: 0 }
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchReferrals = async () => {
      if (!user) return;

      const { data: referralData } = await supabase
        .from('referrals')
        .select('*')
        .eq('referrer_id', user.id)
        .order('created_at', { ascending: false });

      // Fetch referred user details separately
      const enrichedReferrals = [];
      if (referralData) {
        for (const ref of referralData) {
          const { data: referred } = await supabase
            .from('profiles')
            .select('username, created_at, total_invested')
            .eq('id', ref.referred_id)
            .single();
          enrichedReferrals.push({ ...ref, referred });
        }
      }

      if (enrichedReferrals.length > 0) {
        setReferrals(enrichedReferrals);

        // Calculate stats
        const stats = {
          level1: { active: 0, inactive: 0, earnings: 0 },
          level2: { active: 0, inactive: 0, earnings: 0 },
          level3: { active: 0, inactive: 0, earnings: 0 }
        };

        enrichedReferrals.forEach((ref: any) => {
          const level = `level${ref.level}` as keyof typeof stats;
          const isActive = ref.referred.total_invested > 0;
          
          if (isActive) {
            stats[level].active++;
          } else {
            stats[level].inactive++;
          }
          stats[level].earnings += Number(ref.total_earnings);
        });

        setReferralStats(stats);
      }

      setLoading(false);
    };

    fetchReferrals();
  }, [user]);

  const getReferralsByLevel = (level: number) => {
    return referrals.filter(ref => ref.level === level);
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-card border-b border-border px-4 py-4 flex items-center gap-3 sticky top-0">
        <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard')}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-bold">My Team</h1>
      </div>

      <div className="p-4 space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-3 gap-3">
          <Card className="p-3 text-center">
            <p className="text-sm text-muted-foreground">Level 1</p>
            <p className="text-2xl font-bold text-primary">{referralStats.level1.active + referralStats.level1.inactive}</p>
            <p className="text-xs text-success">15% bonus</p>
          </Card>
          <Card className="p-3 text-center">
            <p className="text-sm text-muted-foreground">Level 2</p>
            <p className="text-2xl font-bold text-primary">{referralStats.level2.active + referralStats.level2.inactive}</p>
            <p className="text-xs text-success">3% bonus</p>
          </Card>
          <Card className="p-3 text-center">
            <p className="text-sm text-muted-foreground">Level 3</p>
            <p className="text-2xl font-bold text-primary">{referralStats.level3.active + referralStats.level3.inactive}</p>
            <p className="text-xs text-success">2% bonus</p>
          </Card>
        </div>

        {/* Total Earnings */}
        <Card className="p-4 bg-gradient-success text-white">
          <p className="text-sm opacity-90">Total Referral Earnings</p>
          <p className="text-3xl font-bold">
            {(referralStats.level1.earnings + referralStats.level2.earnings + referralStats.level3.earnings).toLocaleString()} UGX
          </p>
        </Card>

        {/* Referrals Tabs */}
        <Tabs defaultValue="level1" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="level1">Level 1</TabsTrigger>
            <TabsTrigger value="level2">Level 2</TabsTrigger>
            <TabsTrigger value="level3">Level 3</TabsTrigger>
          </TabsList>

          {[1, 2, 3].map(level => (
            <TabsContent key={level} value={`level${level}`} className="space-y-3 mt-4">
              {getReferralsByLevel(level).length === 0 ? (
                <Card className="p-8 text-center">
                  <Users className="h-12 w-12 mx-auto mb-3 text-muted-foreground" />
                  <p className="text-muted-foreground">No referrals yet</p>
                </Card>
              ) : (
                getReferralsByLevel(level).map((ref: any) => {
                  const isActive = ref.referred.total_invested > 0;
                  return (
                    <Card key={ref.id} className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`h-10 w-10 rounded-full flex items-center justify-center ${
                            isActive ? 'bg-success/20' : 'bg-muted'
                          }`}>
                            {isActive ? (
                              <CheckCircle className="h-5 w-5 text-success" />
                            ) : (
                              <XCircle className="h-5 w-5 text-muted-foreground" />
                            )}
                          </div>
                          <div>
                            <p className="font-semibold">{ref.referred.username}</p>
                            <p className="text-sm text-muted-foreground">
                              {isActive ? 'Active' : 'Inactive'}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-success">
                            {Number(ref.total_earnings).toLocaleString()} UGX
                          </p>
                          <p className="text-xs text-muted-foreground">Earned</p>
                        </div>
                      </div>
                    </Card>
                  );
                })
              )}
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </div>
  );
};

export default Team;
