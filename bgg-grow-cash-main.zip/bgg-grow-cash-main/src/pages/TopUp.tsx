import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';
import { z } from 'zod';

const depositSchema = z.object({
  fullName: z.string().min(2, 'Full name is required').max(100),
  phoneNumber: z.string().length(9, 'Phone number must be 9 digits').regex(/^\d{9}$/, 'Invalid phone number'),
  amount: z.number().min(10000, 'Minimum deposit is 10,000 UGX').max(5000000, 'Maximum deposit is 5,000,000 UGX')
});

const TopUp = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [systemSettings, setSystemSettings] = useState<Record<string, string>>({});
  const [formData, setFormData] = useState({
    fullName: '',
    phoneNumber: '',
    amount: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    const fetchSettings = async () => {
      const { data } = await supabase.from('system_settings').select('*');
      if (data) {
        const settingsMap = data.reduce((acc, setting) => {
          acc[setting.setting_key] = setting.setting_value;
          return acc;
        }, {} as Record<string, string>);
        setSystemSettings(settingsMap);
      }
    };
    fetchSettings();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});
    setLoading(true);

    try {
      const amount = parseFloat(formData.amount);
      depositSchema.parse({
        ...formData,
        amount
      });

      // Call Marz Pay deposit edge function
      const { data, error } = await supabase.functions.invoke('marzpay-deposit', {
        body: {
          amount: amount,
          phoneNumber: '+256' + formData.phoneNumber,
          fullName: formData.fullName
        }
      });

      if (error) throw error;

      if (data.error) {
        toast.error(data.error);
        return;
      }

      toast.success(data.message || 'Deposit initiated! Please approve the payment on your phone.');
      navigate('/dashboard');
    } catch (err) {
      if (err instanceof z.ZodError) {
        const fieldErrors: Record<string, string> = {};
        err.errors.forEach((error) => {
          if (error.path) {
            fieldErrors[error.path[0]] = error.message;
          }
        });
        setErrors(fieldErrors);
        toast.error('Please check your inputs');
      } else {
        toast.error('Failed to initiate deposit');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-card border-b border-border px-4 py-4 flex items-center gap-3 sticky top-0">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => navigate('/dashboard')}
        >
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-bold">Top-Up</h1>
      </div>

      <div className="p-4 space-y-6">
        <Card className="p-4 space-y-2">
          <h3 className="font-semibold">Deposit Limits</h3>
          <p className="text-sm text-muted-foreground">
            Minimum: {systemSettings.min_deposit || '10,000'} UGX
          </p>
          <p className="text-sm text-muted-foreground">
            Maximum: {systemSettings.max_deposit || '5,000,000'} UGX
          </p>
          <p className="text-sm text-accent">
            Daily earnings: {systemSettings.daily_earnings_percentage || '12'}%
          </p>
        </Card>

        <Card className="p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="fullName">Full Name</Label>
              <Input
                id="fullName"
                value={formData.fullName}
                onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                placeholder="Enter your full name"
              />
              {errors.fullName && <p className="text-sm text-destructive">{errors.fullName}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="phoneNumber">Phone Number</Label>
              <div className="flex gap-2">
                <Input
                  value="+256"
                  disabled
                  className="w-16 text-center"
                />
                <Input
                  id="phoneNumber"
                  value={formData.phoneNumber}
                  onChange={(e) => {
                    const value = e.target.value.replace(/\D/g, '');
                    if (value.length <= 9) {
                      setFormData({ ...formData, phoneNumber: value });
                    }
                  }}
                  placeholder="700000000"
                  maxLength={9}
                />
              </div>
              {errors.phoneNumber && <p className="text-sm text-destructive">{errors.phoneNumber}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="amount">Amount (UGX)</Label>
              <Input
                id="amount"
                type="number"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                placeholder="10000"
              />
              {errors.amount && <p className="text-sm text-destructive">{errors.amount}</p>}
            </div>

            <Button type="submit" className="w-full bg-gradient-primary" disabled={loading}>
              {loading ? 'Initiating Payment...' : 'Deposit Now'}
            </Button>
          </form>
        </Card>
      </div>
    </div>
  );
};

export default TopUp;
