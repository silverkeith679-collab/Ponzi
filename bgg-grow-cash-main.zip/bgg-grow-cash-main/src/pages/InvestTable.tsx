import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowLeft, Download } from 'lucide-react';
import { toast } from 'sonner';
import investmentTableImage from '@/assets/investment-table.jpg';

const InvestTable = () => {
  const navigate = useNavigate();
  const [downloading, setDownloading] = useState(false);

  const investmentPlans = [
    { price: 10000, dailyEarning: 1200, duration: 60 },
    { price: 20000, dailyEarning: 2400, duration: 60 },
    { price: 50000, dailyEarning: 6000, duration: 60 },
    { price: 100000, dailyEarning: 12000, duration: 60 },
    { price: 300000, dailyEarning: 36000, duration: 60 },
    { price: 500000, dailyEarning: 60000, duration: 60 },
    { price: 1000000, dailyEarning: 120000, duration: 60 },
    { price: 2000000, dailyEarning: 240000, duration: 60 },
    { price: 3000000, dailyEarning: 360000, duration: 60 },
    { price: 5000000, dailyEarning: 600000, duration: 60 },
    { price: 10000000, dailyEarning: 1200000, duration: 60 },
  ];

  const downloadTable = () => {
    setDownloading(true);
    
    // Create CSV content
    const headers = ['Price (UGX)', 'Daily Earnings (UGX)', 'Total Returns (UGX)', 'Duration (Days)'];
    const csvContent = [
      headers.join(','),
      ...investmentPlans.map(plan => 
        [plan.price, plan.dailyEarning, plan.dailyEarning * plan.duration, plan.duration].join(',')
      )
    ].join('\n');

    // Create blob and download
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'BGG_CASH_Investment_Table.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);

    setTimeout(() => {
      setDownloading(false);
      toast.success('Investment table downloaded!');
    }, 500);
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-card border-b border-border px-4 py-4 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard')}>
            <ArrowLeft className="h-6 w-6" />
          </Button>
          <h1 className="text-xl font-bold">BGG CASH Investment Table</h1>
        </div>
        <Button
          onClick={downloadTable}
          disabled={downloading}
          className="bg-gradient-primary"
          size="sm"
        >
          <Download className="h-4 w-4 mr-2" />
          Download
        </Button>
      </div>

      <div className="p-4 space-y-4">
        {/* Investment Table Image */}
        <Card className="overflow-hidden">
          <img 
            src={investmentTableImage} 
            alt="BGG CASH Investment Table - 12% Daily for 60 Days"
            className="w-full h-auto"
          />
        </Card>

        {/* Information Card */}
        <Card className="p-4 bg-primary/10 border-primary/20">
          <h3 className="font-bold mb-2 text-lg">Investment Information</h3>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li>• All investments have a fixed duration of 60 days</li>
            <li>• Daily earnings: 12% of investment amount</li>
            <li>• Daily earnings are credited automatically at 12:00 AM EAT</li>
            <li>• Minimum investment: 10,000 UGX</li>
            <li>• Maximum investment: 10,000,000 UGX</li>
            <li>• Withdrawal available anytime after first earning</li>
          </ul>
        </Card>

        {/* CTA Button */}
        <Button
          onClick={() => navigate('/top-up')}
          className="w-full bg-gradient-primary text-lg py-6"
        >
          Start Investing Now
        </Button>
      </div>
    </div>
  );
};

export default InvestTable;
