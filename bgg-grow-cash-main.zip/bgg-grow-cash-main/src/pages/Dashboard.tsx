import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Menu, Settings, ArrowLeft, Wallet, TrendingUp, Briefcase, Download, DollarSign, RefreshCw, Building2, FileText, Users, Home, PieChart, Download as DownloadIcon, Shield } from 'lucide-react';
import { toast } from 'sonner';

const Dashboard = () => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showMenu, setShowMenu] = useState(false);
  const [systemSettings, setSystemSettings] = useState<Record<string, string>>({});
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      if (!user) return;

      // Fetch all data in parallel for faster loading
      const [profileResult, settingsResult, roleResult] = await Promise.all([
        supabase.from('profiles').select('*').eq('id', user.id).single(),
        supabase.from('system_settings').select('*'),
        supabase.from('user_roles').select('role').eq('user_id', user.id).eq('role', 'admin').maybeSingle()
      ]);

      setIsAdmin(!!roleResult.data);

      if (profileResult.data) setProfile(profileResult.data);
      
      if (settingsResult.data) {
        const settingsMap = settingsResult.data.reduce((acc, setting) => {
          acc[setting.setting_key] = setting.setting_value;
          return acc;
        }, {} as Record<string, string>);
        setSystemSettings(settingsMap);
      }

      setLoading(false);
    };

    fetchData();

    // Set up realtime subscription for profile updates only
    const channel = supabase
      .channel('profile_changes')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'profiles',
          filter: `id=eq.${user?.id}`
        },
        (payload) => {
          // Only update profile state, don't refetch everything
          if (payload.new) {
            setProfile(payload.new);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const copyReferralLink = () => {
    if (profile?.referral_code) {
      const link = `${window.location.origin}/register?rx=${profile.referral_code}`;
      navigator.clipboard.writeText(link);
      toast.success('Referral link copied!');
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-card border-b border-border px-4 py-4 flex items-center justify-between sticky top-0 z-10">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setShowMenu(!showMenu)}
        >
          <Menu className="h-6 w-6" />
        </Button>
        
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate('/settings')}
          >
            <Settings className="h-6 w-6" />
          </Button>
          <div className="h-10 w-10 rounded-full bg-gradient-primary flex items-center justify-center text-white font-bold">
            {profile?.username?.charAt(0).toUpperCase()}
          </div>
        </div>
      </div>

      {/* Side Menu */}
      {showMenu && (
        <div className="fixed inset-0 bg-black/50 z-20" onClick={() => setShowMenu(false)}>
          <div className="bg-card w-80 h-full overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            {/* Menu Header */}
            <div className="p-6 border-b border-border">
              <h1 className="text-3xl font-bold">
                BGG CASH<span className="text-primary">.</span>
              </h1>
            </div>

            {/* Menu Items */}
            <div className="p-4 space-y-1">
              <Button 
                variant="ghost" 
                className="w-full justify-start text-base h-12 hover:bg-primary/10 hover:text-primary" 
                onClick={() => { navigate('/dashboard'); setShowMenu(false); }}
              >
                <Home className="mr-3 h-5 w-5 text-primary" /> 
                <span className="text-primary font-semibold">Dashboard</span>
              </Button>

              <Button 
                variant="ghost" 
                className="w-full justify-start text-base h-12" 
                onClick={() => { navigate('/top-up'); setShowMenu(false); }}
              >
                <DollarSign className="mr-3 h-5 w-5" /> Deposit
              </Button>

              <Button 
                variant="ghost" 
                className="w-full justify-start text-base h-12" 
                onClick={() => { navigate('/withdraw'); setShowMenu(false); }}
              >
                <Building2 className="mr-3 h-5 w-5" /> Withdraw
              </Button>

              <Button 
                variant="ghost" 
                className="w-full justify-start text-base h-12" 
                onClick={() => { navigate('/invest-table'); setShowMenu(false); }}
              >
                <PieChart className="mr-3 h-5 w-5" /> Invest Table
              </Button>

              <Button 
                variant="ghost" 
                className="w-full justify-start text-base h-12" 
                onClick={() => { navigate('/records'); setShowMenu(false); }}
              >
                <FileText className="mr-3 h-5 w-5" /> Records
              </Button>

              <Button 
                variant="ghost" 
                className="w-full justify-start text-base h-12" 
                onClick={() => { navigate('/team'); setShowMenu(false); }}
              >
                <Users className="mr-3 h-5 w-5" /> Team Mates
              </Button>

              <Button 
                variant="ghost" 
                className="w-full justify-start text-base h-12 text-destructive hover:text-destructive hover:bg-destructive/10" 
                onClick={() => { signOut(); setShowMenu(false); }}
              >
                <ArrowLeft className="mr-3 h-5 w-5" /> Logout
              </Button>
            </div>
          </div>
        </div>
      )}

      <div className="p-4 space-y-6">
        {/* Welcome Card */}
        <div className="bg-success/10 border border-success/20 rounded-2xl p-4">
          <p className="text-foreground">Hello, <span className="font-bold">{profile?.username}</span></p>
          <p className="text-muted-foreground">Welcome to BGG CASH.</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3 sm:gap-4">
          <Card className="p-3 sm:p-4 space-y-2">
            <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
              <Wallet className="h-5 w-5 sm:h-6 sm:w-6 text-primary" />
            </div>
            <p className="text-xl sm:text-2xl font-bold text-center break-words">{Number(profile?.account_balance || 0).toLocaleString()}</p>
            <p className="text-xs sm:text-sm text-muted-foreground text-center">Account Balance</p>
          </Card>

          <Card className="p-3 sm:p-4 space-y-2">
            <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-full bg-success/10 flex items-center justify-center mx-auto">
              <TrendingUp className="h-5 w-5 sm:h-6 sm:w-6 text-success" />
            </div>
            <p className="text-xl sm:text-2xl font-bold text-center break-words">{Number(profile?.total_income || 0).toLocaleString()}</p>
            <p className="text-xs sm:text-sm text-muted-foreground text-center">Income</p>
          </Card>

          <Card className="p-3 sm:p-4 space-y-2">
            <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-full bg-accent/10 flex items-center justify-center mx-auto">
              <Briefcase className="h-5 w-5 sm:h-6 sm:w-6 text-accent" />
            </div>
            <p className="text-xl sm:text-2xl font-bold text-center break-words">{Number(profile?.total_invested || 0).toLocaleString()}</p>
            <p className="text-xs sm:text-sm text-muted-foreground text-center">Invested</p>
          </Card>

          <Card className="p-3 sm:p-4 space-y-2">
            <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-full bg-warning/10 flex items-center justify-center mx-auto">
              <Download className="h-5 w-5 sm:h-6 sm:w-6 text-warning" />
            </div>
            <p className="text-xl sm:text-2xl font-bold text-center break-words">{Number(profile?.total_withdrawn || 0).toLocaleString()}</p>
            <p className="text-xs sm:text-sm text-muted-foreground text-center">Withdrawn</p>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-4 gap-2 sm:gap-3">
          <Button
            variant="outline"
            className="flex flex-col h-auto py-3 sm:py-4"
            onClick={() => navigate('/top-up')}
          >
            <DollarSign className="h-5 w-5 sm:h-6 sm:w-6 mb-1" />
            <span className="text-[10px] sm:text-xs">Top-Up</span>
          </Button>

          <Button
            variant="outline"
            className="flex flex-col h-auto py-3 sm:py-4"
            onClick={() => navigate('/re-invest')}
          >
            <RefreshCw className="h-5 w-5 sm:h-6 sm:w-6 mb-1" />
            <span className="text-[10px] sm:text-xs">Re-invest</span>
          </Button>

          <Button
            variant="outline"
            className="flex flex-col h-auto py-3 sm:py-4"
            onClick={() => navigate('/withdraw')}
          >
            <Building2 className="h-5 w-5 sm:h-6 sm:w-6 mb-1" />
            <span className="text-[10px] sm:text-xs">Withdraw</span>
          </Button>

          <Button
            variant="outline"
            className="flex flex-col h-auto py-3 sm:py-4"
            onClick={() => navigate('/records')}
          >
            <FileText className="h-5 w-5 sm:h-6 sm:w-6 mb-1" />
            <span className="text-[10px] sm:text-xs">Records</span>
          </Button>
        </div>

        {/* Referral Program */}
        <Card className="p-4 space-y-3">
          <h3 className="font-bold text-lg">Referral Program</h3>
          <p className="text-sm text-muted-foreground">Invite friends & earn rewards</p>
          <div className="flex gap-2">
            <Input 
              value={`${window.location.origin}/register?rx=${profile?.referral_code}`}
              readOnly
              className="flex-1 text-sm"
            />
            <Button onClick={copyReferralLink} size="sm">Copy</Button>
          </div>
        </Card>

        {/* Admin Dashboard Button */}
        {isAdmin && (
          <Button 
            variant="default" 
            className="w-full flex items-center justify-center gap-2 bg-gradient-primary" 
            onClick={() => navigate('/admin')}
          >
            <Shield className="h-5 w-5" />
            Admin Dashboard
          </Button>
        )}

        {/* WhatsApp Links */}
        <div className="grid grid-cols-2 gap-4">
          <Button
            variant="outline"
            className="h-auto py-4 flex flex-col"
            onClick={() => systemSettings.whatsapp_group_link && window.open(systemSettings.whatsapp_group_link, '_blank')}
            disabled={!systemSettings.whatsapp_group_link}
          >
            <div className="text-success mb-2">📱</div>
            <p className="font-bold text-sm">WHATSAPP GROUP</p>
            <p className="text-xs text-muted-foreground">Join WhatsApp Group</p>
          </Button>

          <Button
            variant="outline"
            className="h-auto py-4 flex flex-col"
            onClick={() => systemSettings.whatsapp_help_link && window.open(systemSettings.whatsapp_help_link, '_blank')}
            disabled={!systemSettings.whatsapp_help_link}
          >
            <div className="text-foreground mb-2">💬</div>
            <p className="font-bold text-sm">WHATSAPP HELP</p>
            <p className="text-xs text-muted-foreground">Chat on WhatsApp</p>
          </Button>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border flex justify-around py-3">
        <Button variant="ghost" className="flex flex-col items-center text-primary" onClick={() => navigate('/dashboard')}>
          <Home className="h-5 w-5" />
          <span className="text-xs mt-1">Home</span>
        </Button>

        <Button variant="ghost" className="flex flex-col items-center" onClick={() => navigate('/invest')}>
          <PieChart className="h-5 w-5" />
          <span className="text-xs mt-1">Invest</span>
        </Button>

        <Button variant="ghost" className="flex flex-col items-center" onClick={() => navigate('/team')}>
          <Users className="h-5 w-5" />
          <span className="text-xs mt-1">Team</span>
        </Button>

        <Button variant="ghost" className="flex flex-col items-center" onClick={() => navigate('/app')}>
          <DownloadIcon className="h-5 w-5" />
          <span className="text-xs mt-1">App</span>
        </Button>
      </div>
    </div>
  );
};

export default Dashboard;
