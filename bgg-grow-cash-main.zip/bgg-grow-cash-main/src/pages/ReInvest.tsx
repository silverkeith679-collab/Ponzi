import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';

const ReInvest = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [profile, setProfile] = useState<any>(null);
  const [systemSettings, setSystemSettings] = useState<Record<string, string>>({});
  const [amount, setAmount] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      if (!user) return;

      const { data: profileData } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      const { data: settingsData } = await supabase
        .from('system_settings')
        .select('*');

      if (profileData) setProfile(profileData);
      
      if (settingsData) {
        const settingsMap = settingsData.reduce((acc, setting) => {
          acc[setting.setting_key] = setting.setting_value;
          return acc;
        }, {} as Record<string, string>);
        setSystemSettings(settingsMap);
      }
    };
    fetchData();
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !profile) return;

    setLoading(true);

    try {
      const investAmount = parseFloat(amount);
      const minDeposit = parseFloat(systemSettings.min_deposit || '10000');

      if (investAmount < minDeposit) {
        throw new Error(`Minimum investment is ${minDeposit} UGX`);
      }

      if (investAmount > profile.account_balance) {
        throw new Error('Insufficient balance');
      }

      const dailyEarningsPercentage = parseFloat(systemSettings.daily_earnings_percentage || '12');
      const dailyEarnings = (investAmount * dailyEarningsPercentage) / 100;

      // Create investment
      const { error: investError } = await supabase
        .from('investments')
        .insert({
          user_id: user.id,
          amount: investAmount,
          daily_earnings: dailyEarnings,
          days_remaining: 60,
          status: 'active'
        });

      if (investError) throw investError;

      // Update profile balance and total_invested
      const { error: profileError } = await supabase
        .from('profiles')
        .update({
          account_balance: profile.account_balance - investAmount,
          total_invested: profile.total_invested + investAmount
        })
        .eq('id', user.id);

      if (profileError) throw profileError;

      // Create transaction record
      await supabase
        .from('transactions')
        .insert({
          user_id: user.id,
          transaction_type: 're-investment',
          amount: investAmount,
          status: 'approved'
        });

      toast.success('Re-investment successful!');
      navigate('/invest');
    } catch (error: any) {
      toast.error(error.message || 'Failed to re-invest');
    } finally {
      setLoading(false);
    }
  };

  const calculateDailyEarnings = () => {
    const investAmount = parseFloat(amount) || 0;
    const dailyEarningsPercentage = parseFloat(systemSettings.daily_earnings_percentage || '12');
    return (investAmount * dailyEarningsPercentage) / 100;
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-card border-b border-border px-4 py-4 flex items-center gap-3 sticky top-0">
        <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard')}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-bold">Re-invest</h1>
      </div>

      <div className="p-4 space-y-6">
        <Card className="p-4 space-y-2">
          <h3 className="font-semibold">Available Balance</h3>
          <p className="text-3xl font-bold text-primary">
            {Number(profile?.account_balance || 0).toLocaleString()} UGX
          </p>
          <p className="text-sm text-accent">
            Daily earnings: {systemSettings.daily_earnings_percentage || '12'}%
          </p>
        </Card>

        <Card className="p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Amount to Invest (UGX)</Label>
              <Input
                id="amount"
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="10000"
                required
              />
            </div>

            {amount && (
              <Card className="p-4 bg-success/10 border-success/20">
                <p className="text-sm">
                  Daily earnings: <strong>{calculateDailyEarnings().toLocaleString()} UGX</strong>
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Investment expires after 60 days
                </p>
              </Card>
            )}

            <Button type="submit" className="w-full bg-gradient-primary" disabled={loading}>
              {loading ? 'Processing...' : 'Invest Now'}
            </Button>
          </form>
        </Card>
      </div>
    </div>
  );
};

export default ReInvest;
