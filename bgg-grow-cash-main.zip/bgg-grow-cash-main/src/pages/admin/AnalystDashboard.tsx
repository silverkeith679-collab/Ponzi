import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, DollarSign, TrendingUp, Activity } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

interface Transaction {
  id: string;
  user_id: string;
  amount: number;
  transaction_type: string;
  status: string;
  created_at: string;
  processed_at: string | null;
  full_name: string | null;
  phone_number: string | null;
  profile?: { username: string };
}

const AnalystDashboard = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [isAnalyst, setIsAnalyst] = useState(false);
  const [loading, setLoading] = useState(true);
  const [pendingTransactions, setPendingTransactions] = useState<Transaction[]>([]);
  const [completedTransactions, setCompletedTransactions] = useState<Transaction[]>([]);
  const [stats, setStats] = useState({
    totalPending: 0,
    totalCompleted: 0,
    pendingAmount: 0,
    completedAmount: 0
  });

  useEffect(() => {
    const checkAnalyst = async () => {
      if (!user) return;

      const { data } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id)
        .in('role', ['analyst', 'admin']);

      if (!data || data.length === 0) {
        toast.error('Access denied. Analyst or Admin role required.');
        navigate('/dashboard');
        return;
      }

      setIsAnalyst(true);
      await fetchTransactions();
      setLoading(false);
    };

    checkAnalyst();
  }, [user, navigate]);

  const fetchTransactions = async () => {
    // Fetch pending transactions
    const { data: pendingData } = await supabase
      .from('transactions')
      .select('*')
      .eq('status', 'pending')
      .order('created_at', { ascending: false });

    // Fetch completed transactions
    const { data: completedData } = await supabase
      .from('transactions')
      .select('*')
      .in('status', ['approved', 'rejected'])
      .order('processed_at', { ascending: false })
      .limit(100);

    // Enrich with usernames
    const enrichTransactions = async (transactions: any[]) => {
      const enriched = [];
      for (const tx of transactions) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('username')
          .eq('id', tx.user_id)
          .single();
        enriched.push({ ...tx, profile });
      }
      return enriched;
    };

    if (pendingData) {
      const enriched = await enrichTransactions(pendingData);
      setPendingTransactions(enriched);
      
      setStats(prev => ({
        ...prev,
        totalPending: enriched.length,
        pendingAmount: enriched.reduce((sum, tx) => sum + Number(tx.amount), 0)
      }));
    }

    if (completedData) {
      const enriched = await enrichTransactions(completedData);
      setCompletedTransactions(enriched);
      
      setStats(prev => ({
        ...prev,
        totalCompleted: enriched.filter(tx => tx.status === 'approved').length,
        completedAmount: enriched
          .filter(tx => tx.status === 'approved')
          .reduce((sum, tx) => sum + Number(tx.amount), 0)
      }));
    }
  };

  const TransactionCard = ({ transaction }: { transaction: Transaction }) => (
    <Card className="p-4">
      <div className="space-y-2">
        <div className="flex justify-between items-start">
          <div>
            <p className="font-semibold">
              {transaction.profile?.username} - {transaction.transaction_type}
            </p>
            <p className="text-sm text-muted-foreground">
              {format(new Date(transaction.created_at), 'MMM dd, yyyy HH:mm')}
            </p>
          </div>
          <div className="text-right">
            <p className="text-xl font-bold text-primary">
              {Number(transaction.amount).toLocaleString()} UGX
            </p>
            <span className={`text-xs px-2 py-1 rounded-full ${
              transaction.status === 'approved' ? 'bg-success/20 text-success' :
              transaction.status === 'pending' ? 'bg-warning/20 text-warning' :
              'bg-destructive/20 text-destructive'
            }`}>
              {transaction.status}
            </span>
          </div>
        </div>

        {(transaction.full_name || transaction.phone_number) && (
          <div className="text-sm space-y-1 pt-2 border-t">
            {transaction.full_name && (
              <p><strong>Name:</strong> {transaction.full_name}</p>
            )}
            {transaction.phone_number && (
              <p><strong>Phone:</strong> {transaction.phone_number}</p>
            )}
            {transaction.processed_at && (
              <p className="text-muted-foreground">
                Processed: {format(new Date(transaction.processed_at), 'MMM dd, yyyy HH:mm')}
              </p>
            )}
          </div>
        )}
      </div>
    </Card>
  );

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    );
  }

  if (!isAnalyst) return null;

  return (
    <div className="min-h-screen bg-background pb-6">
      <div className="bg-card border-b border-border px-4 py-4 flex items-center gap-3 sticky top-0 z-10">
        <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard')}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-bold">Analyst Dashboard</h1>
      </div>

      <div className="p-4 space-y-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-warning/10 flex items-center justify-center">
                <Activity className="h-5 w-5 text-warning" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.totalPending}</p>
                <p className="text-xs text-muted-foreground">Pending</p>
              </div>
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-success/10 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.totalCompleted}</p>
                <p className="text-xs text-muted-foreground">Completed</p>
              </div>
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-warning/10 flex items-center justify-center">
                <DollarSign className="h-5 w-5 text-warning" />
              </div>
              <div>
                <p className="text-lg font-bold">{stats.pendingAmount.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">Pending Amount</p>
              </div>
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-success/10 flex items-center justify-center">
                <DollarSign className="h-5 w-5 text-success" />
              </div>
              <div>
                <p className="text-lg font-bold">{stats.completedAmount.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">Completed Amount</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="pending" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="pending">Pending ({stats.totalPending})</TabsTrigger>
            <TabsTrigger value="completed">Completed ({stats.totalCompleted})</TabsTrigger>
          </TabsList>

          <TabsContent value="pending" className="mt-4 space-y-3">
            {pendingTransactions.length === 0 ? (
              <Card className="p-8 text-center">
                <p className="text-muted-foreground">No pending transactions</p>
              </Card>
            ) : (
              pendingTransactions.map(tx => (
                <TransactionCard key={tx.id} transaction={tx} />
              ))
            )}
          </TabsContent>

          <TabsContent value="completed" className="mt-4 space-y-3">
            {completedTransactions.length === 0 ? (
              <Card className="p-8 text-center">
                <p className="text-muted-foreground">No completed transactions</p>
              </Card>
            ) : (
              completedTransactions.map(tx => (
                <TransactionCard key={tx.id} transaction={tx} />
              ))
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AnalystDashboard;
