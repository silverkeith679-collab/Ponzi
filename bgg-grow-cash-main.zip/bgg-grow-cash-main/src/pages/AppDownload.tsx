import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowLeft, Download, Smartphone } from 'lucide-react';
import { toast } from 'sonner';

const AppDownload = () => {
  const navigate = useNavigate();
  const [downloadLink, setDownloadLink] = useState('');
  const [loading, setLoading] = useState(true);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    const fetchDownloadLink = async () => {
      const { data } = await supabase
        .from('system_settings')
        .select('setting_value')
        .eq('setting_key', 'app_download_link')
        .single();

      if (data) setDownloadLink(data.setting_value);
      setLoading(false);
    };
    fetchDownloadLink();

    // Register service worker
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js');
    }

    // Listen for beforeinstallprompt event
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    });
  }, []);

  const handleDownload = () => {
    if (downloadLink) {
      window.open(downloadLink, '_blank');
    }
  };

  const handleInstallPWA = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        toast.success('App installed successfully!');
      }
      setDeferredPrompt(null);
    } else {
      toast.info('App is already installed or your browser does not support installation');
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-card border-b border-border px-4 py-4 flex items-center gap-3 sticky top-0">
        <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard')}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-bold">Download App</h1>
      </div>

      <div className="p-4 flex items-center justify-center min-h-[calc(100vh-80px)]">
        <Card className="p-8 text-center max-w-md w-full">
          {loading ? (
            <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent mx-auto"></div>
          ) : (
            <div className="space-y-6">
              <div className="flex justify-center">
                <div className="h-24 w-24 rounded-3xl overflow-hidden bg-gradient-primary flex items-center justify-center">
                  <img src="/logo.png" alt="BGG CASH" className="h-full w-full object-cover" />
                </div>
              </div>

              <div className="text-center space-y-2">
                <h2 className="text-2xl font-bold">BGG CASH Mobile App</h2>
                <p className="text-muted-foreground">
                  Install our app on your home screen for quick access
                </p>
              </div>

              <div className="space-y-3">
                <Button 
                  onClick={handleInstallPWA} 
                  className="w-full h-14 text-lg bg-gradient-primary"
                >
                  <Download className="mr-2 h-5 w-5" />
                  Add to Home Screen
                </Button>

                {downloadLink && (
                  <Button 
                    onClick={handleDownload} 
                    variant="outline"
                    className="w-full h-14 text-lg"
                  >
                    <Download className="mr-2 h-5 w-5" />
                    Download APK
                  </Button>
                )}
              </div>

              <div className="bg-muted/50 rounded-lg p-4 text-sm space-y-2">
                <p className="font-semibold">How to install:</p>
                <ol className="list-decimal list-inside space-y-1 text-muted-foreground">
                  <li>Tap "Add to Home Screen" button above</li>
                  <li>Follow your browser's instructions</li>
                  <li>Find BGG CASH icon on your home screen</li>
                </ol>
              </div>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
};

export default AppDownload;
