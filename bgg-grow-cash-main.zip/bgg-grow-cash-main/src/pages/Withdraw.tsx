import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';
import { z } from 'zod';

const Withdraw = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [profile, setProfile] = useState<any>(null);
  const [systemSettings, setSystemSettings] = useState<Record<string, string>>({});
  const [hasActiveInvestment, setHasActiveInvestment] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    phoneNumber: '',
    amount: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    const fetchData = async () => {
      if (!user) return;

      const { data: profileData } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      const { data: settingsData } = await supabase
        .from('system_settings')
        .select('*');

      const { data: investmentData } = await supabase
        .from('investments')
        .select('id')
        .eq('user_id', user.id)
        .eq('status', 'active')
        .limit(1);

      if (profileData) setProfile(profileData);
      setHasActiveInvestment(investmentData && investmentData.length > 0);
      
      if (settingsData) {
        const settingsMap = settingsData.reduce((acc, setting) => {
          acc[setting.setting_key] = setting.setting_value;
          return acc;
        }, {} as Record<string, string>);
        setSystemSettings(settingsMap);
      }
    };
    fetchData();
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !profile) return;

    setErrors({});
    setLoading(true);

    try {
      const amount = parseFloat(formData.amount);
      const minWithdrawal = parseFloat(systemSettings.min_withdrawal || '5000');
      const withdrawalFee = parseFloat(systemSettings.withdrawal_fee_percentage || '10');

      if (amount < minWithdrawal) {
        throw new Error(`Minimum withdrawal is ${minWithdrawal} UGX`);
      }

      if (amount > profile.account_balance) {
        throw new Error('Insufficient balance');
      }

      const netPayout = amount - (amount * withdrawalFee / 100);

      // Deduct amount from account immediately
      const { error: profileError } = await supabase
        .from('profiles')
        .update({
          account_balance: profile.account_balance - amount
        })
        .eq('id', user.id);

      if (profileError) throw profileError;

      // Create pending withdrawal transaction for admin approval
      const { error: transactionError } = await supabase
        .from('transactions')
        .insert({
          user_id: user.id,
          transaction_type: 'withdrawal',
          amount: amount,
          net_payout: netPayout,
          status: 'pending',
          full_name: formData.fullName,
          phone_number: '+256' + formData.phoneNumber,
          payment_method: 'marzpay',
        });

      if (transactionError) {
        // Refund on error
        await supabase
          .from('profiles')
          .update({ account_balance: profile.account_balance })
          .eq('id', user.id);
        throw transactionError;
      }

      toast.success('Withdrawal request submitted! Waiting for admin approval.');
      navigate('/dashboard');
    } catch (error: any) {
      toast.error(error.message || 'Failed to submit withdrawal request');
    } finally {
      setLoading(false);
    }
  };

  const calculateNetPayout = () => {
    const amount = parseFloat(formData.amount) || 0;
    const withdrawalFee = parseFloat(systemSettings.withdrawal_fee_percentage || '10');
    return amount - (amount * withdrawalFee / 100);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-card border-b border-border px-4 py-4 flex items-center gap-3 sticky top-0">
        <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard')}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-bold">Withdraw</h1>
      </div>

      <div className="p-4 space-y-6">
        <Card className="p-4 space-y-2">
          <h3 className="font-semibold">Available Balance</h3>
          <p className="text-3xl font-bold text-primary">
            {Number(profile?.account_balance || 0).toLocaleString()} UGX
          </p>
          <p className="text-sm text-muted-foreground">
            Minimum withdrawal: {systemSettings.min_withdrawal || '5,000'} UGX
          </p>
          <p className="text-sm text-warning">
            Withdrawal fee: {systemSettings.withdrawal_fee_percentage || '10'}%
          </p>
        </Card>

        {!hasActiveInvestment && (
          <Card className="p-4 bg-destructive/10 border-destructive/20">
            <p className="text-destructive font-semibold">⚠️ Withdrawal Not Available</p>
            <p className="text-sm text-muted-foreground mt-2">
              You need an active investment to withdraw funds. Please invest first.
            </p>
          </Card>
        )}

        <Card className="p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="fullName">Full Name</Label>
              <Input
                id="fullName"
                value={formData.fullName}
                onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                placeholder="Enter your full name"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phoneNumber">Phone Number</Label>
              <div className="flex gap-2">
                <Input
                  value="+256"
                  disabled
                  className="w-16 text-center"
                />
                <Input
                  id="phoneNumber"
                  value={formData.phoneNumber}
                  onChange={(e) => {
                    const value = e.target.value.replace(/\D/g, '');
                    if (value.length <= 9) {
                      setFormData({ ...formData, phoneNumber: value });
                    }
                  }}
                  placeholder="700000000"
                  maxLength={9}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="amount">Amount (UGX)</Label>
              <Input
                id="amount"
                type="number"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                placeholder="5000"
                required
              />
            </div>

            {formData.amount && (
              <Card className="p-4 bg-success/10 border-success/20">
                <p className="text-sm">
                  You will receive: <strong>{calculateNetPayout().toLocaleString()} UGX</strong>
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  After {systemSettings.withdrawal_fee_percentage}% fee deduction
                </p>
              </Card>
            )}

            <Button type="submit" className="w-full bg-gradient-primary" disabled={loading || !hasActiveInvestment}>
              {loading ? 'Processing...' : 'Request Withdrawal'}
            </Button>
          </form>
        </Card>
      </div>
    </div>
  );
};

export default Withdraw;
