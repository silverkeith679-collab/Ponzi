import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';

const Index = () => {
  const navigate = useNavigate();

  return (
    <div className="flex min-h-screen items-center justify-center bg-background">
      <div className="text-center space-y-6 p-4">
        <h1 className="text-5xl font-bold bg-gradient-primary bg-clip-text text-transparent">
          BGG CASH
        </h1>
        <p className="text-xl text-muted-foreground">Smart Investment Platform</p>
        <div className="flex gap-4 justify-center">
          <Button onClick={() => navigate('/login')} className="bg-gradient-primary">
            Login
          </Button>
          <Button onClick={() => navigate('/register')} variant="outline">
            Register
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Index;
