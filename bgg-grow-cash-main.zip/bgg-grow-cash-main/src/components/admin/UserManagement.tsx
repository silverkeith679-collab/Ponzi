import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { Ban, RefreshCw, Shield } from 'lucide-react';
import { format } from 'date-fns';

const UserManagement = () => {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [processingId, setProcessingId] = useState<string | null>(null);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    const { data } = await supabase
      .from('profiles')
      .select('*')
      .order('created_at', { ascending: false });

    if (data) setUsers(data);
    setLoading(false);
  };

  const handleBanUser = async (userId: string, isBanned: boolean) => {
    setProcessingId(userId);

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ is_banned: !isBanned })
        .eq('id', userId);

      if (error) throw error;

      toast.success(isBanned ? 'User unbanned' : 'User banned');
      await fetchUsers();
    } catch (error: any) {
      toast.error(error.message || 'Failed to update user');
    } finally {
      setProcessingId(null);
    }
  };

  const handleResetPassword = async (userId: string) => {
    setProcessingId(userId);

    try {
      // In production, you'd send a password reset email
      toast.info('Password reset functionality would be implemented here');
    } catch (error: any) {
      toast.error(error.message || 'Failed to reset password');
    } finally {
      setProcessingId(null);
    }
  };

  const filteredUsers = users.filter(user =>
    user.username?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.full_name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <Input
        placeholder="Search users..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="w-full"
      />

      <div className="space-y-3">
        {filteredUsers.map((user) => (
          <Card key={user.id} className={`p-4 ${user.is_banned ? 'border-destructive' : ''}`}>
            <div className="space-y-3">
              <div className="flex justify-between items-start">
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-semibold">{user.username}</p>
                    {user.is_banned && (
                      <span className="text-xs bg-destructive text-destructive-foreground px-2 py-1 rounded">
                        BANNED
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">{user.full_name}</p>
                  <p className="text-xs text-muted-foreground">
                    Joined: {format(new Date(user.created_at), 'MMM dd, yyyy')}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">Balance</p>
                  <p className="font-bold">{Number(user.account_balance).toLocaleString()} UGX</p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 text-xs">
                <div>
                  <p className="text-muted-foreground">Invested</p>
                  <p className="font-medium">{Number(user.total_invested).toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Income</p>
                  <p className="font-medium">{Number(user.total_income).toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Withdrawn</p>
                  <p className="font-medium">{Number(user.total_withdrawn).toLocaleString()}</p>
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  onClick={() => handleBanUser(user.id, user.is_banned)}
                  disabled={processingId === user.id}
                  variant={user.is_banned ? "default" : "destructive"}
                  size="sm"
                  className="flex-1"
                >
                  <Ban className="mr-2 h-4 w-4" />
                  {user.is_banned ? 'Unban' : 'Ban'}
                </Button>
                <Button
                  onClick={() => handleResetPassword(user.id)}
                  disabled={processingId === user.id}
                  variant="outline"
                  size="sm"
                  className="flex-1"
                >
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Reset Password
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default UserManagement;
