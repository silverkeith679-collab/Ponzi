import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { Ban, Edit, Eye, Shield, UserPlus } from 'lucide-react';
import { format } from 'date-fns';

interface Profile {
  id: string;
  username: string;
  full_name: string | null;
  phone_number: string | null;
  account_balance: number;
  total_income: number;
  total_invested: number;
  total_withdrawn: number;
  is_banned: boolean;
  created_at: string;
}

const EnhancedUserManagement = () => {
  const [users, setUsers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [editingUser, setEditingUser] = useState<Profile | null>(null);
  const [editForm, setEditForm] = useState({
    account_balance: '',
    total_income: '',
    total_invested: '',
    total_withdrawn: '',
    full_name: '',
    phone_number: ''
  });
  const [roleForm, setRoleForm] = useState<{ userId: string; role: 'user' | 'analyst' | 'admin' }>({ 
    userId: '', 
    role: 'user' 
  });

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    const { data } = await supabase
      .from('profiles')
      .select('*')
      .order('created_at', { ascending: false });

    if (data) setUsers(data);
    setLoading(false);
  };

  const handleBanUser = async (userId: string, isBanned: boolean) => {
    setProcessingId(userId);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ is_banned: !isBanned })
        .eq('id', userId);

      if (error) throw error;
      toast.success(isBanned ? 'User unbanned' : 'User banned');
      await fetchUsers();
    } catch (error: any) {
      toast.error(error.message || 'Failed to update user');
    } finally {
      setProcessingId(null);
    }
  };

  const handleEditUser = (user: Profile) => {
    setEditingUser(user);
    setEditForm({
      account_balance: user.account_balance.toString(),
      total_income: user.total_income.toString(),
      total_invested: user.total_invested.toString(),
      total_withdrawn: user.total_withdrawn.toString(),
      full_name: user.full_name || '',
      phone_number: user.phone_number || ''
    });
  };

  const handleSaveEdit = async () => {
    if (!editingUser) return;
    setProcessingId(editingUser.id);

    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          account_balance: parseFloat(editForm.account_balance),
          total_income: parseFloat(editForm.total_income),
          total_invested: parseFloat(editForm.total_invested),
          total_withdrawn: parseFloat(editForm.total_withdrawn),
          full_name: editForm.full_name || null,
          phone_number: editForm.phone_number || null
        })
        .eq('id', editingUser.id);

      if (error) throw error;
      toast.success('User updated successfully');
      setEditingUser(null);
      await fetchUsers();
    } catch (error: any) {
      toast.error(error.message || 'Failed to update user');
    } finally {
      setProcessingId(null);
    }
  };

  const handleViewUserDashboard = async (userId: string) => {
    setProcessingId(userId);
    try {
      const { data, error } = await supabase.rpc('get_user_dashboard_data', {
        target_user_id: userId
      });

      if (error) throw error;
      
      // Store impersonation data
      localStorage.setItem('admin_impersonation', JSON.stringify(data));
      window.open('/dashboard?impersonate=true', '_blank');
      
      toast.success('Opening user dashboard in new tab');
    } catch (error: any) {
      toast.error(error.message || 'Failed to view user dashboard');
    } finally {
      setProcessingId(null);
    }
  };

  const handleAssignRole = async () => {
    if (!roleForm.userId) {
      toast.error('Please select a user');
      return;
    }

    setProcessingId(roleForm.userId);
    try {
      // Check if role already exists
      const { data: existingRole } = await supabase
        .from('user_roles')
        .select('*')
        .eq('user_id', roleForm.userId)
        .eq('role', roleForm.role)
        .single();

      if (existingRole) {
        toast.info('User already has this role');
        return;
      }

      const { error } = await supabase
        .from('user_roles')
        .insert({
          user_id: roleForm.userId,
          role: roleForm.role
        });

      if (error) throw error;
      toast.success(`Role ${roleForm.role} assigned successfully`);
      setRoleForm({ userId: '', role: 'user' });
    } catch (error: any) {
      toast.error(error.message || 'Failed to assign role');
    } finally {
      setProcessingId(null);
    }
  };

  const filteredUsers = users.filter(user =>
    user.username?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.phone_number?.includes(searchTerm)
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Assign Role Card */}
      <Card className="p-4">
        <h3 className="font-semibold mb-3 flex items-center gap-2">
          <Shield className="h-4 w-4" />
          Assign Role
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <Select value={roleForm.userId} onValueChange={(value) => setRoleForm(prev => ({ ...prev, userId: value }))}>
            <SelectTrigger>
              <SelectValue placeholder="Select User" />
            </SelectTrigger>
            <SelectContent>
              {users.map(user => (
                <SelectItem key={user.id} value={user.id}>
                  {user.username}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select 
            value={roleForm.role} 
            onValueChange={(value: 'user' | 'analyst' | 'admin') => setRoleForm(prev => ({ ...prev, role: value }))}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="user">User</SelectItem>
              <SelectItem value="analyst">Analyst</SelectItem>
              <SelectItem value="admin">Admin</SelectItem>
            </SelectContent>
          </Select>

          <Button onClick={handleAssignRole} disabled={!roleForm.userId}>
            <UserPlus className="mr-2 h-4 w-4" />
            Assign Role
          </Button>
        </div>
      </Card>

      <Input
        placeholder="Search users by username, name, or phone..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />

      <div className="space-y-3">
        {filteredUsers.map((user) => (
          <Card key={user.id} className={`p-4 ${user.is_banned ? 'border-destructive' : ''}`}>
            <div className="space-y-3">
              <div className="flex justify-between items-start gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-semibold truncate">{user.username}</p>
                    {user.is_banned && (
                      <span className="text-xs bg-destructive text-destructive-foreground px-2 py-1 rounded">
                        BANNED
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground truncate">{user.full_name}</p>
                  <p className="text-xs text-muted-foreground">
                    {format(new Date(user.created_at), 'MMM dd, yyyy')}
                  </p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-xs text-muted-foreground">Balance</p>
                  <p className="font-bold text-sm">{Number(user.account_balance).toLocaleString()} UGX</p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 text-xs">
                <div>
                  <p className="text-muted-foreground">Invested</p>
                  <p className="font-medium">{Number(user.total_invested).toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Income</p>
                  <p className="font-medium">{Number(user.total_income).toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Withdrawn</p>
                  <p className="font-medium">{Number(user.total_withdrawn).toLocaleString()}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                <Button
                  onClick={() => handleViewUserDashboard(user.id)}
                  disabled={processingId === user.id}
                  variant="outline"
                  size="sm"
                >
                  <Eye className="mr-1 h-3 w-3" />
                  View
                </Button>

                <Dialog>
                  <DialogTrigger asChild>
                    <Button
                      onClick={() => handleEditUser(user)}
                      variant="outline"
                      size="sm"
                    >
                      <Edit className="mr-1 h-3 w-3" />
                      Edit
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-md">
                    <DialogHeader>
                      <DialogTitle>Edit User: {user.username}</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label>Full Name</Label>
                        <Input
                          value={editForm.full_name}
                          onChange={(e) => setEditForm(prev => ({ ...prev, full_name: e.target.value }))}
                        />
                      </div>
                      <div>
                        <Label>Phone Number</Label>
                        <Input
                          value={editForm.phone_number}
                          onChange={(e) => setEditForm(prev => ({ ...prev, phone_number: e.target.value }))}
                        />
                      </div>
                      <div>
                        <Label>Account Balance (UGX)</Label>
                        <Input
                          type="number"
                          value={editForm.account_balance}
                          onChange={(e) => setEditForm(prev => ({ ...prev, account_balance: e.target.value }))}
                        />
                      </div>
                      <div>
                        <Label>Total Income (UGX)</Label>
                        <Input
                          type="number"
                          value={editForm.total_income}
                          onChange={(e) => setEditForm(prev => ({ ...prev, total_income: e.target.value }))}
                        />
                      </div>
                      <div>
                        <Label>Total Invested (UGX)</Label>
                        <Input
                          type="number"
                          value={editForm.total_invested}
                          onChange={(e) => setEditForm(prev => ({ ...prev, total_invested: e.target.value }))}
                        />
                      </div>
                      <div>
                        <Label>Total Withdrawn (UGX)</Label>
                        <Input
                          type="number"
                          value={editForm.total_withdrawn}
                          onChange={(e) => setEditForm(prev => ({ ...prev, total_withdrawn: e.target.value }))}
                        />
                      </div>
                      <Button onClick={handleSaveEdit} disabled={processingId === user.id} className="w-full">
                        Save Changes
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>

                <Button
                  onClick={() => handleBanUser(user.id, user.is_banned)}
                  disabled={processingId === user.id}
                  variant={user.is_banned ? "default" : "destructive"}
                  size="sm"
                >
                  <Ban className="mr-1 h-3 w-3" />
                  {user.is_banned ? 'Unban' : 'Ban'}
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default EnhancedUserManagement;
