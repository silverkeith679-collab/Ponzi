import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { toast } from 'sonner';
import { Check, X } from 'lucide-react';
import { format } from 'date-fns';

interface PendingTransactionsProps {
  onUpdate: () => void;
}

const PendingTransactions = ({ onUpdate }: PendingTransactionsProps) => {
  const [transactions, setTransactions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [systemSettings, setSystemSettings] = useState<Record<string, string>>({});

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const { data: txData } = await supabase
      .from('transactions')
      .select('*')
      .eq('status', 'pending')
      .order('created_at', { ascending: false });

    // Fetch usernames separately
    const enrichedTxData = [];
    if (txData) {
      for (const tx of txData) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('username')
          .eq('id', tx.user_id)
          .single();
        enrichedTxData.push({ ...tx, profile });
      }
    }

    const { data: settingsData } = await supabase
      .from('system_settings')
      .select('*');

    if (enrichedTxData) setTransactions(enrichedTxData);
    
    if (settingsData) {
      const settingsMap = settingsData.reduce((acc, setting) => {
        acc[setting.setting_key] = setting.setting_value;
        return acc;
      }, {} as Record<string, string>);
      setSystemSettings(settingsMap);
    }

    setLoading(false);
  };

  const handleApprove = async (transaction: any) => {
    setProcessingId(transaction.id);

    try {
      if (transaction.transaction_type === 'deposit') {
        await handleDepositApproval(transaction);
        
        // Update status to approved for deposits
        await supabase
          .from('transactions')
          .update({
            status: 'approved',
            processed_at: new Date().toISOString()
          })
          .eq('id', transaction.id);
      } else if (transaction.transaction_type === 'withdrawal') {
        // Withdrawal approval handles its own status update
        await handleWithdrawalApproval(transaction);
      }

      toast.success('Transaction approved!');
      await fetchData();
      onUpdate();
    } catch (error: any) {
      toast.error(error.message || 'Failed to approve transaction');
    } finally {
      setProcessingId(null);
    }
  };

  const handleDepositApproval = async (transaction: any) => {
    const dailyEarningsPercentage = parseFloat(systemSettings.daily_earnings_percentage || '12');
    const dailyEarnings = (transaction.amount * dailyEarningsPercentage) / 100;

    // Create investment
    const { error: investError } = await supabase
      .from('investments')
      .insert({
        user_id: transaction.user_id,
        amount: transaction.amount,
        daily_earnings: dailyEarnings,
        days_remaining: 60,
        status: 'active',
        last_earning_date: new Date().toISOString().split('T')[0]
      });

    if (investError) throw investError;

    // Update profile with immediate earnings
    const { data: profile } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', transaction.user_id)
      .single();

    if (!profile) throw new Error('Profile not found');

    await supabase
      .from('profiles')
      .update({
        total_invested: Number(profile.total_invested) + transaction.amount,
        account_balance: Number(profile.account_balance) + dailyEarnings,
        total_income: Number(profile.total_income) + dailyEarnings
      })
      .eq('id', transaction.user_id);

    // Create immediate earnings transaction
    await supabase
      .from('transactions')
      .insert({
        user_id: transaction.user_id,
        transaction_type: 'daily_earnings',
        amount: dailyEarnings,
        status: 'approved'
      });

    // Process referral bonuses if user has referrers
    await processReferralBonuses(transaction.user_id, transaction.amount);
  };

  const processReferralBonuses = async (userId: string, amount: number) => {
    const { data: referrals } = await supabase
      .from('referrals')
      .select('*')
      .eq('referred_id', userId);

    if (!referrals) return;

    for (const referral of referrals) {
      let bonusPercentage = 0;
      if (referral.level === 1) bonusPercentage = parseFloat(systemSettings.referral_lv1_percentage || '15');
      else if (referral.level === 2) bonusPercentage = parseFloat(systemSettings.referral_lv2_percentage || '3');
      else if (referral.level === 3) bonusPercentage = parseFloat(systemSettings.referral_lv3_percentage || '2');

      const bonusAmount = (amount * bonusPercentage) / 100;

      // Update referrer's balance
      const { data: referrerProfile } = await supabase
        .from('profiles')
        .select('account_balance, total_income')
        .eq('id', referral.referrer_id)
        .single();

      if (referrerProfile) {
        await supabase
          .from('profiles')
          .update({
            account_balance: Number(referrerProfile.account_balance) + bonusAmount,
            total_income: Number(referrerProfile.total_income) + bonusAmount
          })
          .eq('id', referral.referrer_id);

        // Update referral total_earnings
        await supabase
          .from('referrals')
          .update({
            total_earnings: Number(referral.total_earnings) + bonusAmount
          })
          .eq('id', referral.id);

        // Create transaction record
        await supabase
          .from('transactions')
          .insert({
            user_id: referral.referrer_id,
            transaction_type: 'referral_bonus',
            amount: bonusAmount,
            status: 'approved'
          });
      }
    }
  };

  const handleWithdrawalApproval = async (transaction: any) => {
    // Get auth session to call edge function
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session) throw new Error('Not authenticated');

    // Generate unique reference
    const reference = crypto.randomUUID();

    // Update transaction to approved immediately and add reference
    await supabase
      .from('transactions')
      .update({ 
        reference: reference,
        status: 'approved',
        processed_at: new Date().toISOString()
      })
      .eq('id', transaction.id);

    // Update total_withdrawn immediately
    const { data: profile } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', transaction.user_id)
      .single();

    if (!profile) throw new Error('Profile not found');

    await supabase
      .from('profiles')
      .update({
        total_withdrawn: Number(profile.total_withdrawn) + transaction.amount
      })
      .eq('id', transaction.user_id);

    // Call Marz Pay to send money (best effort - status already approved)
    supabase.functions.invoke('marzpay-withdraw', {
      body: {
        transactionId: transaction.id,
        amount: transaction.amount,
        netPayout: transaction.net_payout,
        phoneNumber: transaction.phone_number,
        fullName: transaction.full_name,
        reference: reference
      },
      headers: {
        Authorization: `Bearer ${session.access_token}`
      }
    }).catch(err => {
      console.error('Marzpay call failed but transaction already approved:', err);
    });
  };

  const handleReject = async (transactionId: string) => {
    setProcessingId(transactionId);

    try {
      // Find the transaction
      const { data: transaction } = await supabase
        .from('transactions')
        .select('*')
        .eq('id', transactionId)
        .single();

      if (transaction && transaction.transaction_type === 'withdrawal') {
        // Get user profile
        const { data: profile } = await supabase
          .from('profiles')
          .select('account_balance')
          .eq('id', transaction.user_id)
          .single();

        if (profile) {
          // Refund the amount back to user's account
          await supabase
            .from('profiles')
            .update({
              account_balance: Number(profile.account_balance) + transaction.amount
            })
            .eq('id', transaction.user_id);
        }
      }

      await supabase
        .from('transactions')
        .update({
          status: 'rejected',
          processed_at: new Date().toISOString()
        })
        .eq('id', transactionId);

      toast.success('Transaction rejected');
      await fetchData();
      onUpdate();
    } catch (error: any) {
      toast.error(error.message || 'Failed to reject transaction');
    } finally {
      setProcessingId(null);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    );
  }

  if (transactions.length === 0) {
    return (
      <Card className="p-8 text-center">
        <p className="text-muted-foreground">No pending transactions</p>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      {transactions.map((transaction) => (
        <Card key={transaction.id} className="p-4">
          <div className="space-y-3">
            <div className="flex justify-between items-start">
              <div>
                <p className="font-semibold">
                  {transaction.profile?.username} - {transaction.transaction_type}
                </p>
                <p className="text-sm text-muted-foreground">
                  {format(new Date(transaction.created_at), 'MMM dd, yyyy HH:mm')}
                </p>
              </div>
              <p className="text-xl font-bold text-primary">
                {Number(transaction.amount).toLocaleString()} UGX
              </p>
            </div>

            {transaction.full_name && (
              <div className="text-sm space-y-1">
                <p><strong>Name:</strong> {transaction.full_name}</p>
                <p><strong>Phone:</strong> {transaction.phone_number}</p>
                {transaction.payment_method && (
                  <p><strong>Method:</strong> {transaction.payment_method}</p>
                )}
                {transaction.net_payout && (
                  <p className="text-success">
                    <strong>Net Payout:</strong> {Number(transaction.net_payout).toLocaleString()} UGX
                  </p>
                )}
              </div>
            )}

            <div className="flex gap-2">
              <Button
                onClick={() => handleApprove(transaction)}
                disabled={processingId === transaction.id}
                className="flex-1 bg-gradient-success"
              >
                <Check className="mr-2 h-4 w-4" />
                Approve
              </Button>
              <Button
                onClick={() => handleReject(transaction.id)}
                disabled={processingId === transaction.id}
                variant="destructive"
                className="flex-1"
              >
                <X className="mr-2 h-4 w-4" />
                Reject
              </Button>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
};

export default PendingTransactions;
