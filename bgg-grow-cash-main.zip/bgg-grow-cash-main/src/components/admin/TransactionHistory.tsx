import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { format } from 'date-fns';
import { ArrowUpRight, ArrowDownRight, DollarSign, Gift, Users } from 'lucide-react';

interface Transaction {
  id: string;
  user_id: string;
  amount: number;
  transaction_type: string;
  status: string;
  created_at: string;
  processed_at: string | null;
  phone_number: string | null;
  full_name: string | null;
  reference: string | null;
  profile?: { username: string };
}

const TransactionHistory = () => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  useEffect(() => {
    fetchTransactions();
  }, []);

  const fetchTransactions = async () => {
    const { data: txData } = await supabase
      .from('transactions')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(200);

    // Fetch usernames separately
    const enrichedTxData = [];
    if (txData) {
      for (const tx of txData) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('username')
          .eq('id', tx.user_id)
          .single();
        enrichedTxData.push({ ...tx, profile });
      }
    }

    if (enrichedTxData) setTransactions(enrichedTxData);
    setLoading(false);
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'deposit':
        return <ArrowDownRight className="h-4 w-4 text-success" />;
      case 'withdrawal':
        return <ArrowUpRight className="h-4 w-4 text-warning" />;
      case 'referral_bonus':
        return <Users className="h-4 w-4 text-primary" />;
      case 'welcome_bonus':
        return <Gift className="h-4 w-4 text-accent" />;
      default:
        return <DollarSign className="h-4 w-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'text-success';
      case 'pending':
        return 'text-warning';
      case 'rejected':
        return 'text-destructive';
      default:
        return 'text-muted-foreground';
    }
  };

  const filteredTransactions = transactions.filter(tx => {
    const matchesSearch = 
      tx.profile?.username?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tx.reference?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tx.phone_number?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesType = typeFilter === 'all' || tx.transaction_type === typeFilter;
    const matchesStatus = statusFilter === 'all' || tx.status === statusFilter;

    return matchesSearch && matchesType && matchesStatus;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <Input
          placeholder="Search by username, reference, phone..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger>
            <SelectValue placeholder="Transaction Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="deposit">Deposits</SelectItem>
            <SelectItem value="withdrawal">Withdrawals</SelectItem>
            <SelectItem value="daily_earnings">Daily Earnings</SelectItem>
            <SelectItem value="referral_bonus">Referral Bonus</SelectItem>
            <SelectItem value="welcome_bonus">Welcome Bonus</SelectItem>
          </SelectContent>
        </Select>

        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger>
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="rejected">Rejected</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        {filteredTransactions.map((tx) => (
          <Card key={tx.id} className="p-3">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3 flex-1 min-w-0">
                <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0 mt-0.5">
                  {getTypeIcon(tx.transaction_type)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-semibold text-sm truncate">{tx.profile?.username}</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full bg-muted ${getStatusColor(tx.status)}`}>
                      {tx.status}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground capitalize">
                    {tx.transaction_type.replace('_', ' ')}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {format(new Date(tx.created_at), 'MMM dd, yyyy HH:mm')}
                  </p>
                  {tx.reference && (
                    <p className="text-xs text-muted-foreground truncate">
                      Ref: {tx.reference}
                    </p>
                  )}
                </div>
              </div>
              <div className="text-right flex-shrink-0">
                <p className="text-base font-bold">
                  {Number(tx.amount).toLocaleString()} UGX
                </p>
              </div>
            </div>
          </Card>
        ))}

        {filteredTransactions.length === 0 && (
          <Card className="p-8 text-center">
            <p className="text-muted-foreground">No transactions found</p>
          </Card>
        )}
      </div>
    </div>
  );
};

export default TransactionHistory;
