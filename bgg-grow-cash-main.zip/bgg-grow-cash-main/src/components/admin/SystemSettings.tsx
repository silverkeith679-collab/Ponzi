import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { toast } from 'sonner';

const SystemSettings = () => {
  const [loading, setLoading] = useState(false);
  const [settings, setSettings] = useState<Record<string, string>>({});

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    const { data } = await supabase
      .from('system_settings')
      .select('*');

    if (data) {
      const settingsMap = data.reduce((acc, setting) => {
        acc[setting.setting_key] = setting.setting_value;
        return acc;
      }, {} as Record<string, string>);
      setSettings(settingsMap);
    }
  };

  const handleUpdateSetting = async (key: string, value: string) => {
    setLoading(true);

    try {
      const { error } = await supabase
        .from('system_settings')
        .update({ setting_value: value })
        .eq('setting_key', key);

      if (error) throw error;

      toast.success('Setting updated');
      await fetchSettings();
    } catch (error: any) {
      toast.error(error.message || 'Failed to update setting');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      for (const [key, value] of Object.entries(settings)) {
        await supabase
          .from('system_settings')
          .update({ setting_value: value })
          .eq('setting_key', key);
      }

      toast.success('All settings updated');
    } catch (error: any) {
      toast.error(error.message || 'Failed to update settings');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <Card className="p-4 space-y-4">
        <h3 className="font-semibold text-lg">Investment Settings</h3>
        
        <div className="space-y-2">
          <Label>Daily Earnings Percentage (%)</Label>
          <Input
            type="number"
            step="0.01"
            value={settings.daily_earnings_percentage || ''}
            onChange={(e) => setSettings({ ...settings, daily_earnings_percentage: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label>Investment Duration (days)</Label>
          <Input
            type="number"
            value={settings.investment_duration_days || ''}
            onChange={(e) => setSettings({ ...settings, investment_duration_days: e.target.value })}
          />
        </div>
      </Card>

      <Card className="p-4 space-y-4">
        <h3 className="font-semibold text-lg">Transaction Limits</h3>
        
        <div className="space-y-2">
          <Label>Minimum Deposit (UGX)</Label>
          <Input
            type="number"
            value={settings.min_deposit || ''}
            onChange={(e) => setSettings({ ...settings, min_deposit: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label>Maximum Deposit (UGX)</Label>
          <Input
            type="number"
            value={settings.max_deposit || ''}
            onChange={(e) => setSettings({ ...settings, max_deposit: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label>Minimum Withdrawal (UGX)</Label>
          <Input
            type="number"
            value={settings.min_withdrawal || ''}
            onChange={(e) => setSettings({ ...settings, min_withdrawal: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label>Withdrawal Fee (%)</Label>
          <Input
            type="number"
            step="0.01"
            value={settings.withdrawal_fee_percentage || ''}
            onChange={(e) => setSettings({ ...settings, withdrawal_fee_percentage: e.target.value })}
          />
        </div>
      </Card>

      <Card className="p-4 space-y-4">
        <h3 className="font-semibold text-lg">Referral Bonuses</h3>
        
        <div className="space-y-2">
          <Label>Level 1 Bonus (%)</Label>
          <Input
            type="number"
            step="0.01"
            value={settings.referral_lv1_percentage || ''}
            onChange={(e) => setSettings({ ...settings, referral_lv1_percentage: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label>Level 2 Bonus (%)</Label>
          <Input
            type="number"
            step="0.01"
            value={settings.referral_lv2_percentage || ''}
            onChange={(e) => setSettings({ ...settings, referral_lv2_percentage: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label>Level 3 Bonus (%)</Label>
          <Input
            type="number"
            step="0.01"
            value={settings.referral_lv3_percentage || ''}
            onChange={(e) => setSettings({ ...settings, referral_lv3_percentage: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label>Welcome Bonus (UGX)</Label>
          <Input
            type="number"
            value={settings.welcome_bonus || ''}
            onChange={(e) => setSettings({ ...settings, welcome_bonus: e.target.value })}
          />
        </div>
      </Card>

      <Card className="p-4 space-y-4">
        <h3 className="font-semibold text-lg">Payment Details</h3>
        
        <div className="space-y-2">
          <Label>MTN Account Name</Label>
          <Input
            value={settings.mtn_account_name || ''}
            onChange={(e) => setSettings({ ...settings, mtn_account_name: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label>MTN Account Number</Label>
          <Input
            value={settings.mtn_account_number || ''}
            onChange={(e) => setSettings({ ...settings, mtn_account_number: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label>AIRTEL Account Name</Label>
          <Input
            value={settings.airtel_account_name || ''}
            onChange={(e) => setSettings({ ...settings, airtel_account_name: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label>AIRTEL Account Number</Label>
          <Input
            value={settings.airtel_account_number || ''}
            onChange={(e) => setSettings({ ...settings, airtel_account_number: e.target.value })}
          />
        </div>
      </Card>

      <Card className="p-4 space-y-4">
        <h3 className="font-semibold text-lg">External Links</h3>
        
        <div className="space-y-2">
          <Label>WhatsApp Group Link</Label>
          <Input
            type="url"
            placeholder="https://chat.whatsapp.com/..."
            value={settings.whatsapp_group_link || ''}
            onChange={(e) => setSettings({ ...settings, whatsapp_group_link: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label>WhatsApp Help Link</Label>
          <Input
            type="url"
            placeholder="https://wa.me/..."
            value={settings.whatsapp_help_link || ''}
            onChange={(e) => setSettings({ ...settings, whatsapp_help_link: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label>App Download Link</Label>
          <Input
            type="url"
            placeholder="https://..."
            value={settings.app_download_link || ''}
            onChange={(e) => setSettings({ ...settings, app_download_link: e.target.value })}
          />
        </div>
      </Card>

      <Button type="submit" className="w-full bg-gradient-primary" disabled={loading}>
        {loading ? 'Saving...' : 'Save All Settings'}
      </Button>
    </form>
  );
};

export default SystemSettings;
