import { useState, useEffect } from 'react';

interface CountdownProps {
  targetTime: Date;
}

export const InvestmentCountdown = ({ targetTime }: CountdownProps) => {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  useEffect(() => {
    const calculateTimeLeft = () => {
      const now = new Date();
      const difference = targetTime.getTime() - now.getTime();

      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60)
        });
      } else {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      }
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);

    return () => clearInterval(timer);
  }, [targetTime]);

  return (
    <div className="grid grid-cols-4 gap-2 text-center">
      <div className="bg-primary/10 rounded-lg p-2">
        <p className="text-2xl font-bold text-primary">{timeLeft.days}</p>
        <p className="text-xs text-muted-foreground">Days</p>
      </div>
      <div className="bg-primary/10 rounded-lg p-2">
        <p className="text-2xl font-bold text-primary">{String(timeLeft.hours).padStart(2, '0')}</p>
        <p className="text-xs text-muted-foreground">Hours</p>
      </div>
      <div className="bg-primary/10 rounded-lg p-2">
        <p className="text-2xl font-bold text-primary">{String(timeLeft.minutes).padStart(2, '0')}</p>
        <p className="text-xs text-muted-foreground">Minutes</p>
      </div>
      <div className="bg-primary/10 rounded-lg p-2">
        <p className="text-2xl font-bold text-primary">{String(timeLeft.seconds).padStart(2, '0')}</p>
        <p className="text-xs text-muted-foreground">Seconds</p>
      </div>
    </div>
  );
};
