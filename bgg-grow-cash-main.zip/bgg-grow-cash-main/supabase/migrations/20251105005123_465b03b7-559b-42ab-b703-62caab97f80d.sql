-- Fix the referred_by foreign key constraint issue
-- This constraint is too restrictive and prevents registration

-- Drop the existing foreign key constraint
ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_referred_by_fkey;

-- Now referred_by is just a TEXT field that stores the referral code
-- The trigger function will handle validation