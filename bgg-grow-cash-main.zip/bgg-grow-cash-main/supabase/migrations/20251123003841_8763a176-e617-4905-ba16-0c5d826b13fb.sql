-- Add reference column to transactions table for better webhook matching
ALTER TABLE public.transactions 
ADD COLUMN IF NOT EXISTS reference TEXT UNIQUE;

-- Add index for faster lookups
CREATE INDEX IF NOT EXISTS idx_transactions_reference ON public.transactions(reference);