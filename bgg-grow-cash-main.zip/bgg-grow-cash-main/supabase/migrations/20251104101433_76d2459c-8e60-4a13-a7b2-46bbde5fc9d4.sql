-- Create user profiles table
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT UNIQUE NOT NULL,
  full_name TEXT,
  phone_number TEXT,
  account_balance DECIMAL(15,2) DEFAULT 4000.00,
  total_income DECIMAL(15,2) DEFAULT 4000.00,
  total_invested DECIMAL(15,2) DEFAULT 0.00,
  total_withdrawn DECIMAL(15,2) DEFAULT 0.00,
  referral_code TEXT UNIQUE NOT NULL,
  referred_by TEXT REFERENCES public.profiles(referral_code),
  is_banned BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create user roles enum and table
CREATE TYPE public.app_role AS ENUM ('admin', 'user');

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL DEFAULT 'user',
  UNIQUE(user_id, role)
);

-- Create investments table
CREATE TABLE public.investments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  amount DECIMAL(15,2) NOT NULL,
  daily_earnings DECIMAL(15,2) NOT NULL,
  days_remaining INTEGER DEFAULT 60,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'expired')),
  last_earning_date DATE,
  created_at TIMESTAMPTZ DEFAULT now(),
  expires_at TIMESTAMPTZ DEFAULT now() + INTERVAL '60 days'
);

-- Create transactions table
CREATE TABLE public.transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  transaction_type TEXT NOT NULL CHECK (transaction_type IN ('deposit', 'withdrawal', 'earning', 'referral_bonus', 'welcome_bonus', 're-investment')),
  amount DECIMAL(15,2) NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  full_name TEXT,
  phone_number TEXT,
  payment_method TEXT CHECK (payment_method IN ('MTN', 'AIRTEL', null)),
  net_payout DECIMAL(15,2),
  created_at TIMESTAMPTZ DEFAULT now(),
  processed_at TIMESTAMPTZ
);

-- Create referrals tracking table
CREATE TABLE public.referrals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  referred_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  level INTEGER NOT NULL CHECK (level IN (1, 2, 3)),
  total_earnings DECIMAL(15,2) DEFAULT 0.00,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create system settings table (for admin configuration)
CREATE TABLE public.system_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  setting_key TEXT UNIQUE NOT NULL,
  setting_value TEXT NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Insert default system settings
INSERT INTO public.system_settings (setting_key, setting_value) VALUES
  ('daily_earnings_percentage', '12'),
  ('withdrawal_fee_percentage', '10'),
  ('min_deposit', '10000'),
  ('max_deposit', '5000000'),
  ('min_withdrawal', '5000'),
  ('welcome_bonus', '4000'),
  ('referral_lv1_percentage', '15'),
  ('referral_lv2_percentage', '3'),
  ('referral_lv3_percentage', '2'),
  ('investment_duration_days', '60'),
  ('mtn_account_name', 'Bambalira silver'),
  ('mtn_account_number', '0766637669'),
  ('airtel_account_name', 'Bambalira Silver'),
  ('airtel_account_number', '0759590343'),
  ('whatsapp_group_link', ''),
  ('whatsapp_help_link', ''),
  ('app_download_link', '');

-- Enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.investments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.referrals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_settings ENABLE ROW LEVEL SECURITY;

-- Create security definer function for role checking
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

-- RLS Policies for profiles
CREATE POLICY "Users can view their own profile"
  ON public.profiles FOR SELECT
  USING (auth.uid() = id OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Admins can update any profile"
  ON public.profiles FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Users can view other users for referrals"
  ON public.profiles FOR SELECT
  USING (true);

-- RLS Policies for user_roles
CREATE POLICY "Users can view their own roles"
  ON public.user_roles FOR SELECT
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can manage all roles"
  ON public.user_roles FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for investments
CREATE POLICY "Users can view their own investments"
  ON public.investments FOR SELECT
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "System can create investments"
  ON public.investments FOR INSERT
  WITH CHECK (true);

CREATE POLICY "System can update investments"
  ON public.investments FOR UPDATE
  USING (true);

-- RLS Policies for transactions
CREATE POLICY "Users can view their own transactions"
  ON public.transactions FOR SELECT
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Users can create transactions"
  ON public.transactions FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can update transactions"
  ON public.transactions FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for referrals
CREATE POLICY "Users can view their referrals"
  ON public.referrals FOR SELECT
  USING (auth.uid() = referrer_id OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "System can manage referrals"
  ON public.referrals FOR ALL
  USING (true);

-- RLS Policies for system_settings
CREATE POLICY "Everyone can view system settings"
  ON public.system_settings FOR SELECT
  USING (true);

CREATE POLICY "Admins can update system settings"
  ON public.system_settings FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin'));

-- Create function to handle new user registration
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  ref_code TEXT;
  welcome_bonus DECIMAL(15,2);
BEGIN
  -- Generate unique referral code
  ref_code := UPPER(SUBSTRING(MD5(RANDOM()::TEXT) FROM 1 FOR 8));
  
  -- Get welcome bonus from settings
  SELECT setting_value::DECIMAL INTO welcome_bonus 
  FROM public.system_settings 
  WHERE setting_key = 'welcome_bonus';
  
  -- Create profile with welcome bonus
  INSERT INTO public.profiles (id, username, full_name, phone_number, referral_code, referred_by, account_balance, total_income)
  VALUES (
    NEW.id,
    NEW.raw_user_meta_data->>'username',
    NEW.raw_user_meta_data->>'full_name',
    NEW.raw_user_meta_data->>'phone_number',
    ref_code,
    NEW.raw_user_meta_data->>'referred_by',
    welcome_bonus,
    welcome_bonus
  );
  
  -- Create user role
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'user');
  
  -- Create welcome bonus transaction
  INSERT INTO public.transactions (user_id, transaction_type, amount, status)
  VALUES (NEW.id, 'welcome_bonus', welcome_bonus, 'approved');
  
  -- Handle referral relationships if referred_by exists
  IF NEW.raw_user_meta_data->>'referred_by' IS NOT NULL THEN
    -- Level 1: Direct referrer
    INSERT INTO public.referrals (referrer_id, referred_id, level, is_active)
    SELECT p.id, NEW.id, 1, true
    FROM public.profiles p
    WHERE p.referral_code = NEW.raw_user_meta_data->>'referred_by';
    
    -- Level 2: Referrer's referrer
    INSERT INTO public.referrals (referrer_id, referred_id, level, is_active)
    SELECT p2.id, NEW.id, 2, true
    FROM public.profiles p1
    JOIN public.profiles p2 ON p1.referred_by = p2.referral_code
    WHERE p1.referral_code = NEW.raw_user_meta_data->>'referred_by'
    AND p2.id IS NOT NULL;
    
    -- Level 3: Referrer's referrer's referrer
    INSERT INTO public.referrals (referrer_id, referred_id, level, is_active)
    SELECT p3.id, NEW.id, 3, true
    FROM public.profiles p1
    JOIN public.profiles p2 ON p1.referred_by = p2.referral_code
    JOIN public.profiles p3 ON p2.referred_by = p3.referral_code
    WHERE p1.referral_code = NEW.raw_user_meta_data->>'referred_by'
    AND p3.id IS NOT NULL;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger for new user
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Create triggers for updated_at
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_system_settings_updated_at
  BEFORE UPDATE ON public.system_settings
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at();