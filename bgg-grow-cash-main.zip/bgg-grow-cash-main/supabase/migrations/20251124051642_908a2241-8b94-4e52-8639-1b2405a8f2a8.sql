-- Add analyst role to app_role enum
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'analyst';

-- Create a function to allow admins to impersonate users (for viewing purposes)
CREATE OR REPLACE FUNCTION public.get_user_dashboard_data(target_user_id UUID)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result JSON;
BEGIN
  -- Only admins can call this function
  IF NOT has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Access denied. Admin only.';
  END IF;
  
  -- Get user profile and related data
  SELECT json_build_object(
    'profile', (SELECT row_to_json(p) FROM profiles p WHERE id = target_user_id),
    'transactions', (SELECT json_agg(t) FROM (
      SELECT * FROM transactions WHERE user_id = target_user_id ORDER BY created_at DESC LIMIT 50
    ) t),
    'investments', (SELECT json_agg(i) FROM (
      SELECT * FROM investments WHERE user_id = target_user_id ORDER BY created_at DESC
    ) i),
    'referrals', (SELECT json_agg(r) FROM (
      SELECT * FROM referrals WHERE referrer_id = target_user_id ORDER BY created_at DESC
    ) r)
  ) INTO result;
  
  RETURN result;
END;
$$;