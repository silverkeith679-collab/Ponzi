-- Create function to process daily earnings (runs at midnight EAT)
CREATE OR REPLACE FUNCTION public.process_daily_earnings()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  investment_record RECORD;
  profile_record RECORD;
  today_date DATE := CURRENT_DATE;
BEGIN
  -- Process all active investments
  FOR investment_record IN 
    SELECT * FROM public.investments 
    WHERE status = 'active' 
    AND days_remaining > 0
    AND (last_earning_date IS NULL OR last_earning_date < today_date)
  LOOP
    -- Get user profile
    SELECT * INTO profile_record 
    FROM public.profiles 
    WHERE id = investment_record.user_id;
    
    IF profile_record.id IS NOT NULL THEN
      -- Add daily earnings to user balance
      UPDATE public.profiles
      SET 
        account_balance = account_balance + investment_record.daily_earnings,
        total_income = total_income + investment_record.daily_earnings,
        updated_at = NOW()
      WHERE id = investment_record.user_id;
      
      -- Create earnings transaction
      INSERT INTO public.transactions (user_id, transaction_type, amount, status, created_at)
      VALUES (
        investment_record.user_id,
        'earning',
        investment_record.daily_earnings,
        'approved',
        NOW()
      );
      
      -- Update investment: decrease days remaining
      UPDATE public.investments
      SET 
        days_remaining = days_remaining - 1,
        last_earning_date = today_date,
        status = CASE 
          WHEN days_remaining - 1 <= 0 THEN 'expired'
          ELSE 'active'
        END
      WHERE id = investment_record.id;
      
      RAISE NOTICE 'Processed earnings for user % - Investment %', investment_record.user_id, investment_record.id;
    END IF;
  END LOOP;
  
  RAISE NOTICE 'Daily earnings processing complete';
END;
$$;

-- Enable pg_cron extension if not already enabled
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- Schedule the function to run daily at midnight EAT (21:00 UTC = 00:00 EAT)
-- Clear any existing jobs first
SELECT cron.unschedule(jobid) FROM cron.job WHERE jobname = 'process-daily-earnings';

-- Schedule new job
SELECT cron.schedule(
  'process-daily-earnings',
  '0 21 * * *', -- Every day at 21:00 UTC (midnight EAT)
  $$SELECT public.process_daily_earnings()$$
);