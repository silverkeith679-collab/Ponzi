import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const webhookData = await req.json();
    
    console.log('Marz Pay Webhook received:', JSON.stringify(webhookData));
    
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);
    
    // Extract transaction details from webhook - Marz Pay sends data at root level
    const { transaction, collection, event_type, data } = webhookData;
    
    if (!transaction && !data?.transaction) {
      console.error('Invalid webhook payload - missing transaction:', JSON.stringify(webhookData));
      return new Response('Invalid payload', { status: 400 });
    }
    
    // Support both webhook formats
    const txn = transaction || data?.transaction;
    const coll = collection || data?.collection;
    const reference = txn?.reference || data?.reference;
    
    console.log('Processing webhook - Event:', event_type, 'Transaction status:', txn?.status, 'Reference:', reference);
    
    // Map Marz Pay status to our status
    let transactionStatus = 'pending';
    if (txn?.status === 'successful' || txn?.status === 'completed' || 
        event_type === 'collection.successful' || event_type === 'collection.completed') {
      transactionStatus = 'approved';
    } else if (txn?.status === 'failed' || event_type === 'collection.failed' || 
               txn?.status === 'cancelled' || event_type === 'collection.cancelled') {
      transactionStatus = 'rejected';
    }
    
    // Get the transaction type from event type or description
    const isDeposit = event_type?.includes('collection') || 
                     txn?.description?.includes('Deposit');
    
    // Find the transaction in our database by reference first, then fallback to phone number
    let dbTransaction = null;
    
    if (reference) {
      const { data: refTransactions } = await supabase
        .from('transactions')
        .select('*')
        .eq('reference', reference)
        .eq('status', 'pending')
        .single();
      
      dbTransaction = refTransactions;
      console.log('Found transaction by reference:', reference, dbTransaction ? 'Yes' : 'No');
    }
    
    // Fallback to phone number matching if reference not found
    if (!dbTransaction) {
      const phoneNumber = coll?.phone_number || webhookData.phone_number;
      console.log('Trying to match by phone number:', phoneNumber);
      
      const { data: phoneTransactions } = await supabase
        .from('transactions')
        .select('*')
        .eq('phone_number', phoneNumber)
        .eq('transaction_type', isDeposit ? 'deposit' : 'withdrawal')
        .eq('status', 'pending')
        .order('created_at', { ascending: false })
        .limit(1);
      
      if (phoneTransactions && phoneTransactions.length > 0) {
        dbTransaction = phoneTransactions[0];
        console.log('Found transaction by phone number');
      }
    }
    
    if (!dbTransaction) {
      console.error('No matching transaction found for reference:', reference, 'or webhook data:', JSON.stringify(webhookData));
      return new Response('Transaction not found', { status: 404 });
    }
    
    console.log(`Transaction found: ID=${dbTransaction.id}, Type=${dbTransaction.transaction_type}, Current Status=${dbTransaction.status}`);
    
    // Update transaction status (only for deposits or initial processing)
    // For withdrawals: admin approval is final, don't change approved status
    const shouldUpdateStatus = isDeposit || dbTransaction.status !== 'approved';
    
    if (shouldUpdateStatus) {
      console.log(`Updating transaction ${dbTransaction.id} to status: ${transactionStatus}`);
      
      const { error: updateError } = await supabase
        .from('transactions')
        .update({
          status: transactionStatus,
          processed_at: new Date().toISOString(),
        })
        .eq('id', dbTransaction.id);
      
      if (updateError) {
        console.error('Error updating transaction:', updateError);
        throw updateError;
      }
      
      console.log(`Transaction ${dbTransaction.id} updated successfully to ${transactionStatus}`);
    } else {
      console.log(`Withdrawal transaction ${dbTransaction.id} remains approved (admin decision overrides webhook)`);
    }
    
    // If deposit is successful, update user balance and create investment
    if (isDeposit && transactionStatus === 'approved') {
      console.log(`Processing approved deposit for user ${dbTransaction.user_id}, amount: ${dbTransaction.amount}`);
      
      // Get current balance and system settings
      const { data: profile } = await supabase
        .from('profiles')
        .select('account_balance, total_income, total_invested')
        .eq('id', dbTransaction.user_id)
        .single();
      
      const { data: settings } = await supabase
        .from('system_settings')
        .select('*');
      
      const settingsMap = settings?.reduce((acc, s) => {
        acc[s.setting_key] = s.setting_value;
        return acc;
      }, {} as Record<string, string>) || {};
      
      const dailyEarningsPercentage = parseFloat(settingsMap.daily_earnings_percentage || '12');
      const dailyEarnings = (dbTransaction.amount * dailyEarningsPercentage) / 100;
      
      if (profile) {
        console.log(`Creating investment with daily earnings: ${dailyEarnings}`);
        
        // Create investment
        const { error: investError } = await supabase
          .from('investments')
          .insert({
            user_id: dbTransaction.user_id,
            amount: dbTransaction.amount,
            daily_earnings: dailyEarnings,
            days_remaining: 60,
            status: 'active',
            last_earning_date: new Date().toISOString().split('T')[0]
          });
        
        if (investError) {
          console.error('Error creating investment:', investError);
          throw investError;
        }
        
        // Update profile with investment and immediate earnings
        const { error: balanceError } = await supabase
          .from('profiles')
          .update({
            account_balance: Number(profile.account_balance) + dailyEarnings,
            total_income: Number(profile.total_income) + dailyEarnings,
            total_invested: Number(profile.total_invested) + dbTransaction.amount
          })
          .eq('id', dbTransaction.user_id);
        
        if (balanceError) {
          console.error('Error updating balance:', balanceError);
          throw balanceError;
        }
        
        // Create immediate earnings transaction
        await supabase
          .from('transactions')
          .insert({
            user_id: dbTransaction.user_id,
            transaction_type: 'daily_earnings',
            amount: dailyEarnings,
            status: 'approved'
          });
        
        console.log(`Deposit auto-approved: Investment created, ${dailyEarnings} UGX earnings added to user ${dbTransaction.user_id}`);
        
        // Process referral bonuses
        const { data: referrals } = await supabase
          .from('referrals')
          .select('*')
          .eq('referred_id', dbTransaction.user_id);
        
        if (referrals && referrals.length > 0) {
          console.log(`Processing ${referrals.length} referral bonuses`);
          
          for (const referral of referrals) {
            let bonusPercentage = 0;
            if (referral.level === 1) bonusPercentage = parseFloat(settingsMap.referral_lv1_percentage || '15');
            else if (referral.level === 2) bonusPercentage = parseFloat(settingsMap.referral_lv2_percentage || '3');
            else if (referral.level === 3) bonusPercentage = parseFloat(settingsMap.referral_lv3_percentage || '2');
            
            const bonusAmount = (dbTransaction.amount * bonusPercentage) / 100;
            
            const { data: referrerProfile } = await supabase
              .from('profiles')
              .select('account_balance, total_income')
              .eq('id', referral.referrer_id)
              .single();
            
            if (referrerProfile) {
              await supabase
                .from('profiles')
                .update({
                  account_balance: Number(referrerProfile.account_balance) + bonusAmount,
                  total_income: Number(referrerProfile.total_income) + bonusAmount
                })
                .eq('id', referral.referrer_id);
              
              await supabase
                .from('referrals')
                .update({
                  total_earnings: Number(referral.total_earnings) + bonusAmount
                })
                .eq('id', referral.id);
              
              await supabase
                .from('transactions')
                .insert({
                  user_id: referral.referrer_id,
                  transaction_type: 'referral_bonus',
                  amount: bonusAmount,
                  status: 'approved'
                });
              
              console.log(`Referral bonus of ${bonusAmount} UGX added to user ${referral.referrer_id}`);
            }
          }
        }
      }
    }
    
    // For withdrawals, only log - admin approval is final, no refunds
    if (!isDeposit) {
      if (transactionStatus === 'approved') {
        console.log(`Withdrawal confirmed by Marzpay: ${dbTransaction.amount} UGX sent to user ${dbTransaction.user_id}`);
      } else if (transactionStatus === 'rejected') {
        console.log(`Withdrawal failed at Marzpay but transaction remains approved (admin decision): ${dbTransaction.amount} UGX for user ${dbTransaction.user_id}`);
        // DO NOT refund - admin approval is final
      }
    }
    
    return new Response(
      JSON.stringify({ success: true, message: 'Webhook processed' }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error: any) {
    console.error('Error in marzpay-webhook:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
