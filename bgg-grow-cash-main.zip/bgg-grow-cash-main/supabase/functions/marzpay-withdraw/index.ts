import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { transactionId, amount, netPayout, phoneNumber, fullName, reference } = await req.json();
    
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);
    
    console.log('Processing withdrawal for transaction:', transactionId, 'Reference:', reference);
    
    // Get Marz Pay credentials
    const marzpayKey = Deno.env.get('MARZPAY_API_KEY');
    const marzpaySecret = Deno.env.get('MARZPAY_API_SECRET');
    
    if (!marzpayKey || !marzpaySecret) {
      throw new Error('Marz Pay credentials not configured');
    }
    
    // Create Basic Auth credentials
    const credentials = btoa(`${marzpayKey}:${marzpaySecret}`);
    
    // Webhook URL for callback
    const webhookUrl = `${supabaseUrl}/functions/v1/marzpay-webhook`;
    
    // Call Marz Pay send-money API
    const marzpayResponse = await fetch('https://wallet.wearemarz.com/api/v1/send-money', {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        amount: netPayout,
        phone_number: phoneNumber,
        country: 'UG',
        reference: reference,
        description: `Withdrawal to ${fullName}`,
        callback_url: webhookUrl
      }),
    });
    
    const marzpayData = await marzpayResponse.json();
    
    console.log('Marz Pay Withdraw Response:', marzpayData);
    
    if (marzpayData.status !== 'success') {
      // Log error but don't change transaction status (already approved by admin)
      console.error('Marzpay API failed but transaction already approved:', marzpayData.message);
      throw new Error(marzpayData.message || 'Failed to initiate withdrawal with Marzpay');
    }
    
    // Update payment method but keep status as approved (set by admin)
    await supabase
      .from('transactions')
      .update({ 
        payment_method: marzpayData.data?.disbursement?.provider || 'marzpay'
      })
      .eq('id', transactionId);
    
    return new Response(
      JSON.stringify({
        success: true,
        message: 'Withdrawal sent to Marzpay successfully. Waiting for confirmation.',
        transaction_uuid: marzpayData.data?.transaction?.uuid,
        reference: reference,
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error: any) {
    console.error('Error in marzpay-withdraw:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Failed to process withdrawal' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});