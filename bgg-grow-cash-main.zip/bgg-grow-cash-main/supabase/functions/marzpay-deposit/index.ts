import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { amount, phoneNumber, fullName } = await req.json();
    
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);
    
    // Get user from auth header
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }
    
    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    
    if (userError || !user) {
      throw new Error('Unauthorized');
    }
    
    // Generate unique UUID reference for this transaction
    const reference = crypto.randomUUID();
    
    // Get Marz Pay credentials
    const marzpayKey = Deno.env.get('MARZPAY_API_KEY');
    const marzpaySecret = Deno.env.get('MARZPAY_API_SECRET');
    
    if (!marzpayKey || !marzpaySecret) {
      throw new Error('Marz Pay credentials not configured');
    }
    
    // Create Basic Auth credentials
    const credentials = btoa(`${marzpayKey}:${marzpaySecret}`);
    
    // Webhook URL for callback
    const webhookUrl = `${supabaseUrl}/functions/v1/marzpay-webhook`;
    
    // Call Marz Pay collect-money API
    const marzpayResponse = await fetch('https://wallet.wearemarz.com/api/v1/collect-money', {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${credentials}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        amount: amount,
        phone_number: phoneNumber,
        country: 'UG',
        reference: reference,
        description: `Deposit by ${fullName}`,
        callback_url: webhookUrl
      }),
    });
    
    const marzpayData = await marzpayResponse.json();
    
    console.log('Marz Pay Response:', marzpayData);
    
    if (marzpayData.status !== 'success') {
      throw new Error(marzpayData.message || 'Failed to initiate deposit');
    }
    
    // Create pending transaction in database with reference
    const { error: transactionError } = await supabase
      .from('transactions')
      .insert({
        user_id: user.id,
        transaction_type: 'deposit',
        amount: amount,
        status: 'pending',
        full_name: fullName,
        phone_number: phoneNumber,
        payment_method: marzpayData.data.collection.provider,
        reference: reference,
      });
    
    if (transactionError) {
      console.error('Error creating transaction:', transactionError);
      throw transactionError;
    }
    
    return new Response(
      JSON.stringify({
        success: true,
        message: 'Deposit initiated. Please approve the payment on your phone.',
        transaction_uuid: marzpayData.data.transaction.uuid,
        reference: reference,
        provider: marzpayData.data.collection.provider,
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error: any) {
    console.error('Error in marzpay-deposit:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Failed to process deposit' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
